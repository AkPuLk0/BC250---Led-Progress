import asyncio
import json
import os
import pwd
import shutil
import subprocess
from pathlib import Path
from typing import Any

import decky


class Plugin:
    MANAGED_DEFAULTS: dict[str, Any] = {
        "decky_language": "auto",
        "progress_zone": 1,
        "progress_led_count": 0,
        "max_brightness_percent": 100,
        "monitor_steam_downloads": True,
        "monitor_dolphin_copies": True,
        "monitor_steamos_updates": True,
        "filled_color": [28, 125, 255],
        "copy_filled_color": [180, 60, 255],
        "steamos_update_color": [255, 140, 40],
    }

    COLOR_KEYS = {
        "steam": "filled_color",
        "dolphin": "copy_filled_color",
        "steamos": "steamos_update_color",
    }

    @staticmethod
    def _read_os_release(path: Path = Path("/etc/os-release")) -> dict[str, str]:
        data: dict[str, str] = {}
        try:
            for raw_line in path.read_text(encoding="utf-8").splitlines():
                line = raw_line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                data[key] = value.strip().strip('"').strip("'")
        except OSError:
            pass
        return data

    @classmethod
    def _detect_platform(cls) -> dict[str, Any]:
        data = cls._read_os_release()
        os_id = data.get("ID", "unknown").strip().lower() or "unknown"
        id_like = data.get("ID_LIKE", "").strip().lower()
        pretty_name = data.get("PRETTY_NAME", data.get("NAME", os_id)).strip() or os_id
        haystack = f"{os_id} {id_like} {pretty_name.lower()}"
        if "steamos" in haystack:
            family = "steamos"
            supported = True
        elif "bazzite" in haystack:
            family = "bazzite"
            supported = False
        elif "cachyos" in haystack or "cachy os" in haystack:
            family = "cachyos"
            supported = False
        else:
            family = "other"
            supported = False
        return {
            "platform_id": os_id,
            "platform_name": pretty_name,
            "platform_family": family,
            "steamos_updates_supported": supported,
        }

    def _with_platform(self, managed: dict[str, Any]) -> dict[str, Any]:
        result = dict(managed)
        result.update(self.platform)
        return result

    async def _main(self):
        self.user_home = Path(getattr(decky, "DECKY_USER_HOME", "/home/deck"))
        try:
            self.uid = self.user_home.stat().st_uid
        except OSError:
            self.uid = 1000
        try:
            self.user_name = pwd.getpwuid(self.uid).pw_name
        except KeyError:
            self.user_name = "deck"
        self.config_path = self.user_home / ".config" / "steam-download-rgb" / "config.json"
        self.app_dir = self.user_home / ".local" / "share" / "steam-download-rgb"
        self.platform = self._detect_platform()
        if (
            not self.platform["steamos_updates_supported"]
            and self.config_path.exists()
        ):
            try:
                raw = self._read_raw_config()
                if raw.get("monitor_steamos_updates") is not False:
                    raw["monitor_steamos_updates"] = False
                    self._write_raw_config(raw)
            except Exception as exc:
                decky.logger.warning(
                    f"Unable to migrate SteamOS update tracking for this platform: {exc}"
                )
        decky.logger.info(
            "Steam Download RGB settings plugin ready on "
            f"{self.platform['platform_name']}"
        )

    async def _unload(self):
        decky.logger.info("Steam Download RGB settings plugin unloaded")

    def _validate_color(self, value: Any, name: str) -> list[int]:
        if (
            not isinstance(value, list)
            or len(value) != 3
            or any(not isinstance(component, int) or component < 0 or component > 255 for component in value)
        ):
            raise ValueError(f"{name} doit contenir trois entiers entre 0 et 255")
        return list(value)

    def _validated_managed(self, incoming: dict[str, Any]) -> dict[str, Any]:
        result = dict(self.MANAGED_DEFAULTS)
        result.update({key: incoming[key] for key in self.MANAGED_DEFAULTS if key in incoming})

        if result["decky_language"] not in {"auto", "fr", "en"}:
            raise ValueError("decky_language must be auto, fr or en")

        if not self.platform["steamos_updates_supported"]:
            result["monitor_steamos_updates"] = False

        for key in ("progress_zone", "progress_led_count", "max_brightness_percent"):
            if not isinstance(result[key], int):
                raise ValueError(f"{key} doit être un entier")
        if result["progress_zone"] < 0:
            raise ValueError("progress_zone doit être >= 0")
        if not 0 <= result["progress_led_count"] <= 512:
            raise ValueError("progress_led_count doit être compris entre 0 et 512")
        if not 0 <= result["max_brightness_percent"] <= 100:
            raise ValueError("max_brightness_percent doit être compris entre 0 et 100")

        for key in (
            "monitor_steam_downloads",
            "monitor_dolphin_copies",
            "monitor_steamos_updates",
        ):
            if not isinstance(result[key], bool):
                raise ValueError(f"{key} doit être vrai ou faux")

        for key in ("filled_color", "copy_filled_color", "steamos_update_color"):
            result[key] = self._validate_color(result[key], key)
        return result

    def _read_raw_config(self) -> dict[str, Any]:
        if not self.config_path.exists():
            return {}
        try:
            data = json.loads(self.config_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"Configuration illisible : {exc}") from exc
        if not isinstance(data, dict):
            raise RuntimeError("La configuration doit être un objet JSON")
        return data

    def _write_raw_config(self, data: dict[str, Any]) -> None:
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.config_path.with_suffix(".json.tmp")
        temp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        os.chmod(temp, 0o600)
        os.replace(temp, self.config_path)
        try:
            os.chown(self.config_path, self.uid, self.uid)
        except PermissionError:
            pass

    def _clean_user_environment(self) -> dict[str, str]:
        """Build a minimal environment without Decky's bundled libraries.

        Decky Loader is distributed as a bundled executable and may export an
        LD_LIBRARY_PATH pointing to a temporary ``/tmp/_MEI...`` directory.
        Passing that environment to system binaries such as systemctl can make
        them load Decky's libcrypto instead of SteamOS' libcrypto.  A minimal
        environment prevents that ABI mismatch while preserving access to the
        user's systemd --user bus.
        """
        return {
            "HOME": str(self.user_home),
            "USER": self.user_name,
            "LOGNAME": self.user_name,
            "PATH": "/usr/local/sbin:/usr/local/bin:/usr/bin:/bin",
            "LANG": os.environ.get("LANG", "C.UTF-8"),
            "LC_ALL": os.environ.get("LC_ALL", "C.UTF-8"),
            "XDG_RUNTIME_DIR": f"/run/user/{self.uid}",
            "DBUS_SESSION_BUS_ADDRESS": f"unix:path=/run/user/{self.uid}/bus",
        }

    def _user_command(self, command: list[str], timeout: float = 20.0) -> subprocess.CompletedProcess[str]:
        clean_env = self._clean_user_environment()

        if os.geteuid() == 0 and shutil.which("runuser"):
            runuser = shutil.which("runuser") or "/usr/bin/runuser"
            env_bin = shutil.which("env") or "/usr/bin/env"
            env_args = [f"{key}={value}" for key, value in clean_env.items()]
            full = [runuser, "-u", self.user_name, "--", env_bin, "-i", *env_args, *command]
            return subprocess.run(
                full,
                capture_output=True,
                text=True,
                check=False,
                timeout=timeout,
                env={
                    "PATH": "/usr/local/sbin:/usr/local/bin:/usr/bin:/bin",
                    "LANG": clean_env["LANG"],
                    "LC_ALL": clean_env["LC_ALL"],
                },
            )

        return subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=False,
            timeout=timeout,
            env=clean_env,
        )

    def _service_state_sync(self) -> dict[str, Any]:
        active = self._user_command(
            ["systemctl", "--user", "is-active", "steam-download-rgb.service"],
            timeout=5.0,
        )
        enabled = self._user_command(
            ["systemctl", "--user", "is-enabled", "steam-download-rgb.service"],
            timeout=5.0,
        )
        return {
            "active": active.returncode == 0 and active.stdout.strip() == "active",
            "enabled": enabled.returncode == 0 and enabled.stdout.strip() == "enabled",
            "installed": (self.app_dir / "steam_download_rgb.py").exists(),
            "config_exists": self.config_path.exists(),
        }

    async def get_config(self) -> dict[str, Any]:
        raw = await asyncio.to_thread(self._read_raw_config)
        managed = self._with_platform(self._validated_managed(raw))
        managed["service"] = await asyncio.to_thread(self._service_state_sync)
        return managed

    async def get_service_status(self) -> dict[str, Any]:
        return await asyncio.to_thread(self._service_state_sync)

    async def save_config(self, config: dict[str, Any]) -> dict[str, Any]:
        managed = self._validated_managed(config)
        raw = await asyncio.to_thread(self._read_raw_config)
        raw.pop("reverse", None)
        raw.update(managed)
        await asyncio.to_thread(self._write_raw_config, raw)

        state = await asyncio.to_thread(self._service_state_sync)
        if state["active"]:
            result = await asyncio.to_thread(
                self._user_command,
                ["systemctl", "--user", "restart", "steam-download-rgb.service"],
                20.0,
            )
            if result.returncode != 0:
                raise RuntimeError(result.stderr.strip() or "Redémarrage du service impossible")
        managed = self._with_platform(managed)
        managed["service"] = await asyncio.to_thread(self._service_state_sync)
        return managed

    async def set_service_enabled(self, enabled: bool) -> dict[str, Any]:
        action = "enable" if enabled else "disable"
        result = await asyncio.to_thread(
            self._user_command,
            ["systemctl", "--user", action, "--now", "steam-download-rgb.service"],
            25.0,
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or f"Commande systemctl {action} impossible")
        return await asyncio.to_thread(self._service_state_sync)

    async def test_source(self, source: str, config: dict[str, Any]) -> dict[str, Any]:
        if source not in self.COLOR_KEYS:
            raise ValueError("Source de test inconnue")
        if source == "steamos" and not self.platform["steamos_updates_supported"]:
            raise ValueError("Le suivi des mises à jour SteamOS n'est disponible que sur SteamOS")

        managed = self._validated_managed(config)
        raw = await asyncio.to_thread(self._read_raw_config)
        raw.pop("reverse", None)
        raw.update(managed)
        await asyncio.to_thread(self._write_raw_config, raw)

        state_before = await asyncio.to_thread(self._service_state_sync)
        if state_before["active"]:
            stopped = await asyncio.to_thread(
                self._user_command,
                ["systemctl", "--user", "stop", "steam-download-rgb.service"],
                15.0,
            )
            if stopped.returncode != 0:
                raise RuntimeError(stopped.stderr.strip() or "Arrêt temporaire du service impossible")

        python = self.app_dir / ".venv" / "bin" / "python"
        script = self.app_dir / "steam_download_rgb.py"
        if not python.exists() or not script.exists():
            raise RuntimeError("Le service Steam Download RGB v0.8 n'est pas installé")

        try:
            result = await asyncio.to_thread(
                self._user_command,
                [
                    str(python),
                    str(script),
                    "--config",
                    str(self.config_path),
                    "--preview-source",
                    source,
                    "--preview-progress",
                    "50",
                    "--preview-seconds",
                    "2",
                ],
                20.0,
            )
            if result.returncode != 0:
                raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "Test LED impossible")
        finally:
            if state_before["active"]:
                await asyncio.to_thread(
                    self._user_command,
                    ["systemctl", "--user", "start", "steam-download-rgb.service"],
                    15.0,
                )

        return {
            "ok": True,
            "source": source,
            "service": await asyncio.to_thread(self._service_state_sync),
        }
