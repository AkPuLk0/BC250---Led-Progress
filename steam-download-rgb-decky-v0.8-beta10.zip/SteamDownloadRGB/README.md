# Steam Download RGB Settings — Decky Loader plugin v0.8 beta 10

Optional Gaming Mode settings panel for **Steam Download RGB v0.8**.

## Languages

The panel supports:

- **Automatic**: follows Steam's interface language when French is detected; English is used for every other language;
- **Français**;
- **English**.

The language selector is placed near the bottom of the panel, just before the save button. Changing it updates the interface immediately. Press **Save settings / Enregistrer les réglages** to keep the choice after a restart.

## Requirements

- Steam Download RGB v0.8 installed in `~/.local/share/steam-download-rgb`;
- Decky Loader installed;
- OpenLinkHub/OpenRGB already configured for the main service.

## Menu options

- enable or disable the user service;
- choose the number of LEDs (`0` = automatic);
- set maximum brightness;
- enable or disable Steam and Dolphin tracking;
- on SteamOS, enable or disable SteamOS update tracking;
- cycle through color presets for each source;
- preview each source at 50% for two seconds;
- save settings and restart the service safely.

The backend preserves unknown keys in `~/.config/steam-download-rgb/config.json`,
except for the obsolete `reverse` key, which is removed during migration.

On Bazzite, CachyOS and other non-SteamOS systems, the SteamOS update controls
are hidden and `monitor_steamos_updates` is forced to `false`. Steam downloads
and Dolphin copies remain available.
It only updates settings displayed in the Decky panel, including the UI language preference.

## Beta 10 changes

- detects SteamOS, Bazzite and CachyOS through `/etc/os-release`;
- hides SteamOS update controls outside SteamOS;
- forces `monitor_steamos_updates` to `false` on Bazzite, CachyOS and other non-SteamOS systems;
- keeps Steam and Dolphin tracking available on those systems;
- keeps the language selector near the bottom of the panel;
- keeps the beta 6 clean-environment fix for `systemctl --user`;
- remains matched with the v0.8 beta 3 service.

## Installation from ZIP

1. Install and test the main Steam Download RGB v0.8 service first.
2. Remove an older Steam Download RGB Decky beta if installed.
3. Enable Developer Mode in Decky Loader.
4. Choose **Developer → Install Plugin from ZIP**.
5. Select `steam-download-rgb-decky-v0.8-beta10.zip`.
6. Restart Decky Loader if the panel does not appear immediately.

## Safety

- no password, token, copied-file path or personal serial number is included;
- configuration writes are atomic and mode `0600`;
- LED tests temporarily stop the service, run the v0.8 preview command, restore OpenLinkHub, then restart the service if it was active;
- the plugin never starts a SteamOS update.
