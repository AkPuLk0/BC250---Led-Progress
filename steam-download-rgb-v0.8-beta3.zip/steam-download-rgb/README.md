# Steam Download RGB — SteamOS, Bazzite, CachyOS + OpenLinkHub

## Version v0.8 beta 3 — compatibilité SteamOS, Bazzite et CachyOS

Steam Download RGB transforme une barre ARGB reliée à un **Corsair COMMANDER
DUO** en indicateur de progression sous SteamOS, Bazzite ou CachyOS.

Priorité d'affichage sous SteamOS :

1. mise à jour SteamOS : orange ;
2. téléchargement Steam : bleu ;
3. copie lancée depuis Dolphin : violet ;
4. aucune activité : retour automatique au profil OpenLinkHub, par exemple
   `gpu-temperature`.

Sous Bazzite et CachyOS, le suivi Atomupd est automatiquement désactivé :
Steam et Dolphin restent actifs, sans erreur de diagnostic.

La logique Steam et Dolphin validée dans la v0.7.1 est conservée. La progression
Steam reste celle de la phase réellement publiée par Steam : la v0.8 n'essaie
pas de prédire le nombre de phases et ne fabrique pas de progression globale.

## Nouveautés v0.8

- nombre de LED utilisées réglable ;
- `0` LED dans la configuration signifie détection automatique de toute la zone ;
- luminosité maximale de 0 à 100 % ;
- choix de la zone OpenRGB qui affiche la progression ;
- progression fixe et claire de gauche vers la droite ;
- couleurs séparées pour Steam, Dolphin et SteamOS ;
- activation séparée des trois sources ;
- commande d'aperçu LED pour le plugin Decky Loader ;
- détection passive de la progression SteamOS via Atomupd ;
- détection automatique de SteamOS, Bazzite et CachyOS ;
- désactivation automatique d'Atomupd hors SteamOS ;
- priorité SteamOS > Steam > Dolphin ;
- migration non destructive de la configuration v0.7.1.

> **État du suivi SteamOS : bêta et réservé à SteamOS.** L'interface Atomupd, les propriétés
> `UpdateStatus` et `ProgressPercentage`, ainsi que leur lecture passive ont été
> vérifiées sur SteamOS 3.8.24. Le cycle complet doit encore être validé pendant
> une véritable mise à jour SteamOS. Steam et Dolphin restent indépendants si
> Atomupd est indisponible. Sur Bazzite et CachyOS, Atomupd est ignoré par
> conception.

## Sécurité

- aucune commande ne lance, ne met en pause ou n'annule une mise à jour SteamOS ;
- Atomupd est lu avec `busctl --system get-property` ;
- ventilateurs, pompe, températures et alimentation ne sont jamais modifiés ;
- les profils RGB OpenLinkHub sont mémorisés avant la prise de contrôle ;
- en cas d'arrêt, erreur ou `SIGTERM`, le programme rend les LED à OpenLinkHub ;
- l'installateur ne désactive pas le mode lecture seule de SteamOS ;
- une configuration existante est sauvegardée une fois dans
  `config.json.backup-before-v0.8`, puis complétée sans supprimer ses valeurs.

## Prérequis

OpenLinkHub doit écouter sur son serveur OpenRGB intégré :

```json
{
  "enableOpenRGBTargetServer": true,
  "openRGBPort": 6743
}
```

Vérification :

```bash
ss -ltn | grep ':6743'
```

## Installation ou mise à jour depuis la v0.7.1

```bash
systemctl --user stop steam-download-rgb.service
unzip steam-download-rgb-v0.8.zip
cd steam-download-rgb
chmod +x install.sh uninstall.sh
./install.sh
```

Diagnostic passif :

```bash
~/.local/share/steam-download-rgb/.venv/bin/python \
  ~/.local/share/steam-download-rgb/steam_download_rgb.py --diagnose
```

Test progressif des LED :

```bash
~/.local/share/steam-download-rgb/.venv/bin/python \
  ~/.local/share/steam-download-rgb/steam_download_rgb.py --led-test
```

Puis redémarrage du service :

```bash
systemctl --user enable --now steam-download-rgb.service
```

Journaux :

```bash
journalctl --user -u steam-download-rgb.service -f
```

Restauration d'urgence :

```bash
~/.local/share/steam-download-rgb/.venv/bin/python \
  ~/.local/share/steam-download-rgb/steam_download_rgb.py --restore
```

## Configuration manuelle

Fichier à ouvrir :

```bash
nano ~/.config/steam-download-rgb/config.json
```

Réglages principaux :

```json
{
  "zones": [0, 1],
  "progress_zone": 1,
  "progress_led_count": 8,
  "max_brightness_percent": 70,

  "monitor_steam_downloads": true,
  "monitor_dolphin_copies": true,
  "monitor_steamos_updates": true,

  "filled_color": [28, 125, 255],
  "copy_filled_color": [180, 60, 255],
  "steamos_update_color": [255, 140, 40],
  "empty_color": [0, 0, 0]
}
```

### Nombre de LED

- `"progress_led_count": 0` : utilise automatiquement toutes les LED de la
  zone choisie ;
- `"progress_led_count": 8` : n'utilise que les huit premières LED de la zone ;
- une valeur supérieure au nombre physique est automatiquement limitée ;
- les autres LED et les autres zones restent éteintes pendant la progression.

### Zone utilisée

`progress_zone` correspond au numéro de zone OpenRGB. Avec un COMMANDER DUO
exposant `ARGB Channel 1` puis `ARGB Channel 2`, le canal 2 est généralement la
zone `1`.

L'écriture OpenRGB reste globale, car c'est la méthode fiable avec OpenLinkHub :
toutes les zones listées dans `zones` doivent donc rester sélectionnées, même si
une seule affiche la progression.

### Luminosité

`max_brightness_percent` limite toutes les couleurs envoyées par le programme,
sans modifier les profils `gpu-temperature` gérés par OpenLinkHub au repos.

### Couleurs

Chaque couleur est un tableau RGB : `[rouge, vert, bleu]`, avec des valeurs de
0 à 255.

Après une modification manuelle :

```bash
systemctl --user restart steam-download-rgb.service
```

## Aperçu utilisé par Decky Loader

Exemple : afficher SteamOS à 50 % pendant deux secondes, puis restaurer le
profil température :

```bash
~/.local/share/steam-download-rgb/.venv/bin/python \
  ~/.local/share/steam-download-rgb/steam_download_rgb.py \
  --preview-source steamos \
  --preview-progress 50 \
  --preview-seconds 2
```

Sources possibles : `steam`, `dolphin`, `steamos`.

## Fonctionnement des sources

### Steam

Le programme se connecte au `SharedJSContext` du client Steam via CEF/CDP et
utilise les informations réellement publiées par `DownloadOverview` et
`DownloadItems`. Une future mise à jour du client Steam peut nécessiter une
adaptation de cette API interne non publique.

### Dolphin

Les copies sont lues sur le bus de session KDE via
`org.kde.JobViewServer`/`org.kde.JobViewV3`. Plusieurs copies simultanées sont
pondérées selon leur taille totale. Les commandes `cp` ou `rsync` ne sont pas
nécessairement visibles, contrairement aux copies lancées depuis Dolphin.

### SteamOS

Sur SteamOS uniquement, le programme lit passivement :

```text
com.steampowered.Atomupd1
/com/steampowered/Atomupd1
UpdateStatus
ProgressPercentage
```

Au repos, la lecture est espacée de deux secondes. Pendant une opération active,
elle suit l'intervalle général de la configuration. Sur Bazzite, CachyOS et les
autres systèmes, cette source est désactivée automatiquement.

## Plugin Decky Loader

Le plugin facultatif **Steam Download RGB Settings v0.8** permet depuis le mode
Gaming de régler :

- service actif/inactif ;
- nombre de LED ;
- luminosité ;
- activation de chaque source ;
- couleurs prédéfinies ;
- tests à 50 %.

Le plugin et le service sont distribués séparément : le service fonctionne sans
Decky Loader.

## Vérifications effectuées

- compilation Python ;
- validation syntaxique Bash ;
- 28 tests unitaires et simulations ;
- tests du calcul de zone, du nombre de LED et de la luminosité ;
- tests de parsing Atomupd ;
- vérification du retour OpenLinkHub après erreur ;
- recherche de données personnelles dans l'archive publique.

La première installation doit rester progressive : diagnostic, test LED, puis
service réel. Le suivi SteamOS doit être observé pendant la prochaine véritable
mise à jour avant d'être considéré comme totalement validé.


## Direction et retour au profil normal

La progression est fixe de gauche vers la droite. Après une pause ou une fin, le profil OpenLinkHub est restauré après 2 secondes.
