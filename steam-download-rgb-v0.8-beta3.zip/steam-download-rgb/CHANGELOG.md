## v0.8 beta 3

- Detects SteamOS, Bazzite and CachyOS from `/etc/os-release`.
- Automatically disables SteamOS/Atomupd update tracking outside SteamOS.
- Keeps Steam downloads and Dolphin copies fully active on Bazzite and CachyOS.
- Treats the Decky-only `decky_language` key silently.
- Reports Atomupd as not applicable instead of an error on non-SteamOS systems.

# Changelog

## v0.8.0 beta 2

- Removes the reverse-direction setting from the service and example configuration.
- Migrates existing configurations by deleting the obsolete `reverse` key while preserving all other settings.
- Keeps progress fixed from left to right.
- Keeps the validated 2-second idle restore delay after a pause or completed operation.
- Restarts an already-running user service automatically during an update.

## v0.8.0

- Adds configurable progress zone and LED count.
- Adds a global maximum brightness setting.
- Adds source-specific enable switches and colors.
- Adds read-only SteamOS Atomupd progress monitoring with highest priority.
- Adds LED preview commands for the optional Decky Loader plugin.
- Preserves the v0.7.1 Steam and Dolphin behavior.
- Adds non-destructive config migration and 27 automated tests.

## v0.7.1

- Adds Dolphin/KIO copy progress.
- Preserves the validated v0.7 Steam progress logic.
