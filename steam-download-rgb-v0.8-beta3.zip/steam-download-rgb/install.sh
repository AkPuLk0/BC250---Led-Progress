#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$HOME/.local/share/steam-download-rgb"
CONFIG_DIR="$HOME/.config/steam-download-rgb"
SERVICE_DIR="$HOME/.config/systemd/user"
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SERVICE_NAME="steam-download-rgb.service"
WAS_ACTIVE=false
if systemctl --user is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
  WAS_ACTIVE=true
fi

command -v python3 >/dev/null 2>&1 || {
  echo "Erreur : python3 est introuvable."
  exit 1
}

mkdir -p "$APP_DIR" "$CONFIG_DIR" "$SERVICE_DIR"

cp "$HERE/steam_download_rgb.py" "$APP_DIR/"
cp "$HERE/requirements.txt" "$APP_DIR/"
cp "$HERE/steam-download-rgb.service" "$SERVICE_DIR/"

if [[ ! -f "$CONFIG_DIR/config.json" ]]; then
  cp "$HERE/config.example.json" "$CONFIG_DIR/config.json"
  echo "Configuration créée : $CONFIG_DIR/config.json"
else
  echo "Configuration existante conservée, complétée et nettoyée pour la v0.8 beta 3."
  if [[ ! -f "$CONFIG_DIR/config.json.backup-before-v0.8-beta3" ]]; then
    cp -a "$CONFIG_DIR/config.json" "$CONFIG_DIR/config.json.backup-before-v0.8-beta3"
    echo "Sauvegarde créée : $CONFIG_DIR/config.json.backup-before-v0.8-beta3"
  fi
  python3 - "$CONFIG_DIR/config.json" "$HERE/config.example.json" <<'PYCONFIG'
import json
import os
import sys
from pathlib import Path

current_path = Path(sys.argv[1])
default_path = Path(sys.argv[2])
current = json.loads(current_path.read_text(encoding="utf-8"))
defaults = json.loads(default_path.read_text(encoding="utf-8"))
if not isinstance(current, dict):
    raise SystemExit("Erreur : config.json doit contenir un objet JSON.")
for key, value in defaults.items():
    current.setdefault(key, value)
# La progression publique est désormais toujours de gauche vers la droite.
current.pop("reverse", None)
temp = current_path.with_suffix(".json.tmp")
temp.write_text(json.dumps(current, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
os.chmod(temp, 0o600)
os.replace(temp, current_path)
PYCONFIG
fi

# Atomupd est propre à SteamOS. Sur Bazzite, CachyOS et les autres systèmes,
# le suivi des mises à jour SteamOS est automatiquement désactivé sans toucher
# aux suivis Steam et Dolphin.
python3 - "$CONFIG_DIR/config.json" <<'PYPLATFORM'
import json
import os
import sys
from pathlib import Path

config_path = Path(sys.argv[1])
data = json.loads(config_path.read_text(encoding="utf-8"))

def read_os_release(path=Path("/etc/os-release")):
    result = {}
    try:
        for raw_line in path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            result[key] = value.strip().strip('"').strip("'")
    except OSError:
        pass
    return result

os_release = read_os_release()
os_id = os_release.get("ID", "unknown").lower()
id_like = os_release.get("ID_LIKE", "").lower()
pretty_name = os_release.get("PRETTY_NAME", os_release.get("NAME", os_id))
haystack = f"{os_id} {id_like} {pretty_name.lower()}"
is_steamos = "steamos" in haystack

if not is_steamos:
    data["monitor_steamos_updates"] = False
    temp = config_path.with_suffix(".json.tmp")
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.chmod(temp, 0o600)
    os.replace(temp, config_path)
    print(f"Suivi SteamOS/Atomupd désactivé automatiquement sur {pretty_name}.")
else:
    print(f"SteamOS détecté : suivi Atomupd conservé selon la configuration.")
PYPLATFORM

if [[ ! -x "$APP_DIR/.venv/bin/python" ]]; then
  echo "Création de l'environnement Python..."
  python3 -m venv "$APP_DIR/.venv"
fi

echo "Installation des dépendances Python..."
"$APP_DIR/.venv/bin/python" -m pip install --no-cache-dir -r "$APP_DIR/requirements.txt"

chmod +x "$APP_DIR/steam_download_rgb.py"
systemctl --user daemon-reload

if [[ "$WAS_ACTIVE" == true ]]; then
  systemctl --user restart "$SERVICE_NAME"
  echo "Service existant redémarré avec la nouvelle version."
fi

cat <<EOF

Installation/mise à jour terminée.

1) Diagnostic :
   $APP_DIR/.venv/bin/python $APP_DIR/steam_download_rgb.py --diagnose

2) Lecture SteamOS, Steam et Dolphin sans toucher aux LED :
   $APP_DIR/.venv/bin/python $APP_DIR/steam_download_rgb.py --monitor-only

3) Test LED après activation du serveur OpenRGB dans OpenLinkHub :
   $APP_DIR/.venv/bin/python $APP_DIR/steam_download_rgb.py --led-test

4) Lancement réel :
   $APP_DIR/.venv/bin/python $APP_DIR/steam_download_rgb.py

5) Après validation, si le service n'était pas déjà actif :
   systemctl --user enable --now steam-download-rgb.service
EOF
