Steam Download RGB v0.8 beta 10 bundle
======================================

1. Install the main service first:
   steam-download-rgb-v0.8-beta3.zip

2. Then install the Decky plugin from Decky Developer Mode:
   steam-download-rgb-decky-v0.8-beta10.zip

Platform behavior:
- SteamOS: Steam + Dolphin + SteamOS/Atomupd tracking available.
- Bazzite/CachyOS: Steam + Dolphin remain available; SteamOS/Atomupd tracking is disabled automatically.

The Decky language selector remains available in Automatic, French and English.
The LED idle restore delay remains 2 seconds.
