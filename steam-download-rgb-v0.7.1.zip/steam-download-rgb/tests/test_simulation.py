import importlib.util
import sys
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).resolve().parents[1] / 'steam_download_rgb.py'
spec = importlib.util.spec_from_file_location('steam_download_rgb', MODULE_PATH)
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
assert spec.loader
spec.loader.exec_module(mod)

class FakeZone:
    def __init__(self, n, name='zone'):
        self.leds = [object() for _ in range(n)]
        self.name = name
        self.calls = []
    def set_colors(self, colors, fast=False):
        self.calls.append((colors, fast))


class FakeDevice:
    def __init__(self, n, name='COMMANDER DUO'):
        self.leds = [object() for _ in range(n)]
        self.name = name
        self.calls = []
    def set_colors(self, colors, fast=False):
        self.calls.append((colors, fast))

class Tests(unittest.TestCase):
    def test_normalise_active_item(self):
        state = mod.SteamDownloadReader._normalise({
            'isDownloading': True,
            'sequence': 2,
            'items': [{
                'active': True, 'paused': False, 'appid': 42,
                'downloaded_bytes': 500, 'total_bytes': 1000,
            }],
            'overview': {
                'update_state': 'Updating',
                'update_network_bytes_per_second': 1234,
                'update_seconds_remaining': 9,
            },
        })
        self.assertTrue(state.active)
        self.assertEqual(state.app_id, 42)
        self.assertAlmostEqual(state.percent, 50.0)
        self.assertEqual(state.source, 'items')

    def test_normalise_stale_overview_is_not_active(self):
        state = mod.SteamDownloadReader._normalise({
            'isDownloading': False,
            'items': [],
            'overview': {
                'paused': False,
                'update_state': 'None',
                'update_bytes_downloaded': 500,
                'update_bytes_to_download': 1000,
            },
        })
        self.assertFalse(state.active)

    def test_normalise_current_steam_downloading_state(self):
        state = mod.SteamDownloadReader._normalise({
            'isDownloading': True,
            'items': [],
            'overview': {
                'paused': False,
                'update_state': 'Downloading',
                'update_appid': 1715130,
                'update_bytes_downloaded': 5_000_000_000,
                'update_bytes_to_download': 10_000_000_000,
                'update_network_bytes_per_second': 100_000_000,
            },
        })
        self.assertTrue(state.active)
        self.assertEqual(state.app_id, 1715130)
        self.assertAlmostEqual(state.percent, 50.0)
        self.assertEqual(state.source, 'overview')


    def test_normalise_steamos_nested_schema_overview_percent(self):
        state = mod.SteamDownloadReader._normalise({
            'isDownloading': True,
            'items': [],
            'overview': {
                'paused': False,
                'update_state': 'Downloading',
                'update_appid': 231350,
                'progress_percent': 37.5,
                'update_bytes_downloaded': 3_750_000_000,
                'update_bytes_to_download': 10_000_000_000,
                'update_network_bytes_per_second': 100_000_000,
                'update_seconds_remaining': 60,
            },
        })
        self.assertTrue(state.active)
        self.assertEqual(state.app_id, 231350)
        self.assertAlmostEqual(state.percent, 37.5)
        self.assertEqual(state.source, 'overview')

    def test_overview_progress_wins_over_stale_active_item_percent(self):
        state = mod.SteamDownloadReader._normalise({
            'isDownloading': True,
            'items': [{
                'active': True,
                'paused': False,
                'completed': False,
                'appid': 311730,
                'progress_percent': 1,
                'downloaded_bytes': 0,
                'total_bytes': 7_551_151_665,
            }],
            'overview': {
                'paused': False,
                'update_state': 'Downloading',
                'update_appid': 311730,
                'progress_percent': 16,
                'update_bytes_downloaded': 1_205_103_694,
                'update_bytes_to_download': 7_551_151_665,
                'update_network_bytes_per_second': 98_130_996,
            },
        })
        self.assertTrue(state.active)
        self.assertEqual(state.app_id, 311730)
        self.assertAlmostEqual(state.percent, 16.0)
        self.assertEqual(state.source, 'overview')

    def test_normalise_steamos_active_item_without_legacy_byte_fields(self):
        state = mod.SteamDownloadReader._normalise({
            'isDownloading': True,
            'items': [{
                'active': True,
                'paused': False,
                'completed': False,
                'appid': 231350,
                'progress_percent': 12.25,
                'downloaded_bytes': 0,
                'total_bytes': 0,
                'seconds_remaining': 120,
            }],
            'overview': {
                'paused': False,
                'update_state': 'Downloading',
                'update_appid': 231350,
                'progress_percent': 12.25,
                'update_network_bytes_per_second': 80_000_000,
            },
        })
        self.assertTrue(state.active)
        self.assertEqual(state.app_id, 231350)
        self.assertAlmostEqual(state.percent, 12.25)
        self.assertEqual(state.source, 'overview')

    def test_isdownloading_true_with_idle_overview_is_not_active(self):
        state = mod.SteamDownloadReader._normalise({
            'isDownloading': True,
            'items': [{
                'active': False,
                'paused': False,
                'completed': True,
                'appid': 1715130,
                'progress_percent': 100,
                'downloaded_bytes': 21_330_901_122,
                'total_bytes': 21_330_901_122,
            }],
            'overview': {
                'paused': False,
                'update_state': 'None',
                'update_appid': 0,
                'progress_percent': 0,
                'update_network_bytes_per_second': 0,
            },
        })
        self.assertFalse(state.active)

    def test_normalise_paused(self):
        state = mod.SteamDownloadReader._normalise({
            'isDownloading': False,
            'items': [],
            'overview': {
                'paused': True,
                'update_state': 'Updating',
                'update_bytes_downloaded': 500,
                'update_bytes_to_download': 1000,
            },
        })
        self.assertFalse(state.active)
        self.assertTrue(state.paused)


    def test_javascript_handles_current_steamos_payload_shape(self):
        self.assertIn('item_data', mod.SteamDownloadReader.INSTALL_JS)
        self.assertIn('update_type_info', mod.SteamDownloadReader.INSTALL_JS)
        self.assertIn('overall_percent_complete', mod.SteamDownloadReader.INSTALL_JS)
        self.assertIn('__steamDownloadRGB_v5', mod.SteamDownloadReader.INSTALL_JS)

    def test_openlinkhub_success_requires_status_one(self):
        self.assertTrue(mod.OpenLinkHubController._response_success({'code': 200, 'status': 1}))
        self.assertFalse(mod.OpenLinkHubController._response_success({'code': 200, 'status': 0}))
        self.assertFalse(mod.OpenLinkHubController._response_success({'code': 500, 'status': 1}))

    def test_restore_order_and_payloads(self):
        cfg = mod.Config()
        hub = mod.OpenLinkHubController(cfg)
        hub.serial = 'SERIAL'
        hub.saved_profiles = {0: 'gpu-temperature', 1: 'cpu-temperature'}
        hub.integration_enabled = True
        calls = []
        def fake_post(path, payload):
            calls.append((path, payload.copy()))
            return {'code': 200, 'status': 1}
        hub._post = fake_post
        hub.restore_profiles()
        self.assertEqual(calls[0], ('/api/color/setOpenRgbIntegration', {'deviceId': 'SERIAL', 'mode': 0}))
        self.assertEqual(calls[1], ('/api/color', {'deviceId': 'SERIAL', 'channelId': 0, 'profile': 'gpu-temperature'}))
        self.assertEqual(calls[2], ('/api/color', {'deviceId': 'SERIAL', 'channelId': 1, 'profile': 'cpu-temperature'}))
        hub.close()

    def test_progress_render_is_smooth_and_avoids_exact_duplicates(self):
        cfg = mod.Config(zones=[0], filled_color=[10,20,30], empty_color=[0,0,0])
        bar = mod.OpenRgbProgressBar(cfg)
        bar.client = object()
        bar.device = FakeDevice(10)
        z = FakeZone(10)
        bar.selected_zones = [z]
        bar.render(0.37)
        self.assertEqual(len(bar.device.calls), 1)
        self.assertEqual(len(z.calls), 0)
        colors, fast = bar.device.calls[0]
        self.assertFalse(fast)
        self.assertEqual(sum((c.red, c.green, c.blue) == (10,20,30) for c in colors), 3)
        self.assertEqual((colors[3].red, colors[3].green, colors[3].blue), (7,14,21))
        bar.render(0.37)
        self.assertEqual(len(bar.device.calls), 1)
        bar.render(0.379)
        self.assertEqual(len(bar.device.calls), 2)

    def test_progress_minimum_is_dim_and_full_is_full(self):
        cfg = mod.Config(zones=[0])
        bar = mod.OpenRgbProgressBar(cfg)
        bar.client = object()
        bar.device = FakeDevice(10)
        z = FakeZone(10)
        bar.selected_zones = [z]
        bar.render(0.001)
        colors, _ = bar.device.calls[-1]
        first = (colors[0].red, colors[0].green, colors[0].blue)
        self.assertNotEqual(first, tuple(cfg.empty_color))
        self.assertNotEqual(first, tuple(cfg.filled_color))
        bar.render(1.0)
        colors, _ = bar.device.calls[-1]
        self.assertEqual(sum((c.red, c.green, c.blue) == tuple(cfg.filled_color) for c in colors), 10)

    def test_global_write_concatenates_zone_payloads(self):
        cfg = mod.Config(zones=[0, 1], filled_color=[10,20,30], empty_color=[0,0,0])
        bar = mod.OpenRgbProgressBar(cfg)
        bar.client = object()
        bar.device = FakeDevice(9)
        first = FakeZone(1, 'ARGB Channel 1')
        second = FakeZone(8, 'ARGB Channel 2')
        bar.selected_zones = [first, second]
        bar.render(0.5)
        self.assertEqual(len(first.calls), 0)
        self.assertEqual(len(second.calls), 0)
        colors, fast = bar.device.calls[-1]
        self.assertFalse(fast)
        self.assertEqual(len(colors), 9)
        # Le canal à une LED est à mi-luminosité ; le canal à huit LED en a quatre pleines.
        self.assertEqual((colors[0].red, colors[0].green, colors[0].blue), (5,10,15))
        self.assertEqual(sum((c.red, c.green, c.blue) == (10,20,30) for c in colors), 4)

    def test_single_led_zone_brightness_tracks_progress(self):
        cfg = mod.Config(zones=[0], filled_color=[100,200,250], empty_color=[0,0,0])
        bar = mod.OpenRgbProgressBar(cfg)
        bar.client = object()
        bar.device = FakeDevice(1)
        bar.selected_zones = [FakeZone(1)]
        bar.render(0.25)
        colors, _ = bar.device.calls[-1]
        self.assertEqual((colors[0].red, colors[0].green, colors[0].blue), (25,50,62))
        bar.render(0.75)
        colors, _ = bar.device.calls[-1]
        self.assertEqual((colors[0].red, colors[0].green, colors[0].blue), (75,150,188))

    def test_dolphin_copy_monitor_parses_progress_and_terminate(self):
        monitor = mod.DolphinCopyMonitor()
        monitor._handle_block([
            "method call time=1 sender=:1.199 -> destination=org.kde.JobViewServer "
            "serial=1 path=/org/kde/notificationmanager/jobs/JobView_3; "
            "interface=org.kde.JobViewV3; member=update",
            "   array [",
            "      dict entry(",
            '         string "title"',
            '         variant             string "Copie"',
            "      )",
            "      dict entry(",
            '         string "percent"',
            "         variant             uint32 41",
            "      )",
            "      dict entry(",
            '         string "processedBytes"',
            "         variant             uint64 75815949",
            "      )",
            "      dict entry(",
            '         string "totalBytes"',
            "         variant             uint64 180838439",
            "      )",
            "   ]",
        ])
        state = monitor.snapshot()
        self.assertTrue(state.active)
        self.assertEqual(state.job_count, 1)
        self.assertEqual(state.processed_bytes, 75815949)
        self.assertEqual(state.total_bytes, 180838439)
        self.assertAlmostEqual(state.progress, 75815949 / 180838439)

        monitor._handle_block([
            "method call time=2 sender=:1.199 -> destination=org.kde.JobViewServer "
            "serial=2 path=/org/kde/notificationmanager/jobs/JobView_3; "
            "interface=org.kde.JobViewV3; member=terminate",
            "   uint32 0",
            '   string ""',
            "   array [",
            "   ]",
        ])
        self.assertFalse(monitor.snapshot().active)

    def test_dolphin_copy_monitor_weights_multiple_jobs_by_size(self):
        monitor = mod.DolphinCopyMonitor()
        with monitor._lock:
            monitor._jobs = {
                "a": mod._CopyJob("a", "Copie", 0.5, 50, 100),
                "b": mod._CopyJob("b", "Copie", 0.25, 100, 400),
            }
        state = monitor.snapshot()
        self.assertEqual(state.job_count, 2)
        self.assertEqual(state.processed_bytes, 150)
        self.assertEqual(state.total_bytes, 500)
        self.assertAlmostEqual(state.progress, 0.3)

    def test_progress_render_accepts_copy_color_override(self):
        cfg = mod.Config(zones=[0], filled_color=[10,20,30])
        bar = mod.OpenRgbProgressBar(cfg)
        bar.client = object()
        bar.device = FakeDevice(1)
        bar.selected_zones = [FakeZone(1)]
        bar.render(1.0, filled_color=[180,60,255])
        colors, _ = bar.device.calls[-1]
        self.assertEqual((colors[0].red, colors[0].green, colors[0].blue), (180,60,255))

    def test_run_service_restores_stale_integration_on_start(self):
        stop = mod.threading.Event()
        stop.set()
        instances = {}

        class Reader:
            def __init__(self, cfg): pass
            def close(self): pass

        class Hub:
            def __init__(self, cfg):
                self.serial = 'SERIAL'
                self.saved_profiles = {0: 'gpu-temperature'}
                self.current_openrgb_integration = True
                self.integration_enabled = False
                self.restore_count = 0
                instances['hub'] = self
            def inspect_device(self): return {}
            def restore_profiles(self):
                self.restore_count += 1
                self.integration_enabled = False
                self.current_openrgb_integration = False
            def close(self): pass

        class RGB:
            def __init__(self, cfg): pass
            def disconnect(self): pass

        old = (mod.SteamDownloadReader, mod.OpenLinkHubController, mod.OpenRgbProgressBar)
        mod.SteamDownloadReader, mod.OpenLinkHubController, mod.OpenRgbProgressBar = Reader, Hub, RGB
        try:
            self.assertEqual(mod.run_service(mod.Config(monitor_dolphin_copies=False), stop), 0)
            self.assertEqual(instances['hub'].restore_count, 1)
        finally:
            mod.SteamDownloadReader, mod.OpenLinkHubController, mod.OpenRgbProgressBar = old

    def test_run_service_restores_if_rgb_connect_fails_after_toggle(self):
        stop = mod.threading.Event()
        instances = {}

        class Reader:
            def __init__(self, cfg): pass
            def read(self):
                return mod.DownloadState(active=True, progress=0.25, total_bytes=100)
            def close(self): pass

        class Hub:
            def __init__(self, cfg):
                self.serial = 'SERIAL'
                self.saved_profiles = {0: 'gpu-temperature'}
                self.current_openrgb_integration = False
                self.integration_enabled = False
                self.restore_count = 0
                instances['hub'] = self
            def inspect_device(self): return {}
            def set_openrgb_integration(self, enabled):
                self.integration_enabled = enabled
                self.current_openrgb_integration = enabled
            def restore_profiles(self):
                self.restore_count += 1
                self.integration_enabled = False
                self.current_openrgb_integration = False
            def close(self): pass

        class RGB:
            def __init__(self, cfg): pass
            def connect(self):
                stop.set()
                raise mod.SteamRGBError('échec simulé')
            def disconnect(self): pass

        cfg = mod.Config(reconnect_delay_seconds=0.0, monitor_dolphin_copies=False)
        old = (mod.SteamDownloadReader, mod.OpenLinkHubController, mod.OpenRgbProgressBar)
        mod.SteamDownloadReader, mod.OpenLinkHubController, mod.OpenRgbProgressBar = Reader, Hub, RGB
        try:
            self.assertEqual(mod.run_service(cfg, stop), 0)
            self.assertEqual(instances['hub'].restore_count, 1)
            self.assertFalse(instances['hub'].integration_enabled)
        finally:
            mod.SteamDownloadReader, mod.OpenLinkHubController, mod.OpenRgbProgressBar = old

if __name__ == '__main__':
    unittest.main(verbosity=2)
