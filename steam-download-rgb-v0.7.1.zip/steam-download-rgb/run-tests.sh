#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON="${PYTHON:-python3}"
"$PYTHON" -m compileall -q "$HERE/steam_download_rgb.py"
bash -n "$HERE/install.sh" "$HERE/uninstall.sh"
"$PYTHON" "$HERE/tests/test_simulation.py"
echo "Tous les tests locaux sont passés."
