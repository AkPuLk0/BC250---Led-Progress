#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$HOME/.local/share/steam-download-rgb"
CONFIG_DIR="$HOME/.config/steam-download-rgb"
SERVICE_DIR="$HOME/.config/systemd/user"
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

command -v python3 >/dev/null 2>&1 || {
  echo "Erreur : python3 est introuvable."
  exit 1
}

mkdir -p "$APP_DIR" "$CONFIG_DIR" "$SERVICE_DIR"

cp "$HERE/steam_download_rgb.py" "$APP_DIR/"
cp "$HERE/requirements.txt" "$APP_DIR/"
cp "$HERE/steam-download-rgb.service" "$SERVICE_DIR/"

if [[ ! -f "$CONFIG_DIR/config.json" ]]; then
  cp "$HERE/config.example.json" "$CONFIG_DIR/config.json"
  echo "Configuration créée : $CONFIG_DIR/config.json"
else
  echo "Configuration existante conservée : $CONFIG_DIR/config.json"
fi

if [[ ! -x "$APP_DIR/.venv/bin/python" ]]; then
  echo "Création de l'environnement Python..."
  python3 -m venv "$APP_DIR/.venv"
fi

echo "Installation des dépendances Python..."
"$APP_DIR/.venv/bin/python" -m pip install --no-cache-dir -r "$APP_DIR/requirements.txt"

chmod +x "$APP_DIR/steam_download_rgb.py"
systemctl --user daemon-reload

cat <<EOF

Installation terminée, mais le service n'est pas encore activé.

1) Diagnostic :
   $APP_DIR/.venv/bin/python $APP_DIR/steam_download_rgb.py --diagnose

2) Lecture Steam et Dolphin sans toucher aux LED :
   $APP_DIR/.venv/bin/python $APP_DIR/steam_download_rgb.py --monitor-only

3) Test LED après activation du serveur OpenRGB dans OpenLinkHub :
   $APP_DIR/.venv/bin/python $APP_DIR/steam_download_rgb.py --led-test

4) Lancement réel :
   $APP_DIR/.venv/bin/python $APP_DIR/steam_download_rgb.py

5) Après validation :
   systemctl --user enable --now steam-download-rgb.service
EOF
