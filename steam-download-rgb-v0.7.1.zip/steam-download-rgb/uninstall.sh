#!/usr/bin/env bash
set -euo pipefail

systemctl --user disable --now steam-download-rgb.service 2>/dev/null || true
rm -f "$HOME/.config/systemd/user/steam-download-rgb.service"
rm -rf "$HOME/.local/share/steam-download-rgb"
systemctl --user daemon-reload

echo "Programme supprimé."
echo "Configuration conservée dans : $HOME/.config/steam-download-rgb"
