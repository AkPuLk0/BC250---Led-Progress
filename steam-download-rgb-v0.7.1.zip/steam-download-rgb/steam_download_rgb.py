#!/usr/bin/env python3
"""
Steam Download RGB
==================

Lit la progression des téléchargements Steam via le débogage CEF/CDP et
la progression des copies Dolphin via KDE JobViewServer, puis affiche la
progression active LED par LED sur un périphérique exposé par le serveur
OpenRGB intégré à OpenLinkHub. Steam reste prioritaire sur Dolphin.

Le programme ne touche jamais aux ventilateurs, aux pompes ou aux sondes.
À l'arrêt, il désactive l'intégration OpenRGB et restaure les profils RGB
OpenLinkHub sauvegardés au démarrage.

Testé syntaxiquement avec Python 3.11.
"""

from __future__ import annotations

import argparse
import json
import logging
import math
import re
import signal
import socket
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import requests
import websocket
from openrgb import OpenRGBClient
from openrgb.utils import RGBColor


APP_NAME = "SteamDownloadRGB"
DEFAULT_CONFIG_PATH = Path.home() / ".config" / "steam-download-rgb" / "config.json"

LOG = logging.getLogger(APP_NAME)


class SteamRGBError(RuntimeError):
    """Erreur attendue et présentable à l'utilisateur."""


@dataclass(slots=True)
class Config:
    steam_cef_targets_url: str = "http://127.0.0.1:8080/json"
    openlinkhub_url: str = "http://127.0.0.1:27003"
    commander_serial: str = ""
    commander_name_contains: str = "COMMANDER DUO"

    openrgb_host: str = "127.0.0.1"
    openrgb_port: int = 6743
    openrgb_device_name_contains: str = "COMMANDER DUO"
    zones: list[int] = field(default_factory=lambda: [0, 1])

    poll_interval_seconds: float = 0.5
    idle_restore_delay_seconds: float = 2.0
    reconnect_delay_seconds: float = 2.0
    request_timeout_seconds: float = 4.0

    filled_color: list[int] = field(default_factory=lambda: [28, 125, 255])
    copy_filled_color: list[int] = field(default_factory=lambda: [180, 60, 255])
    empty_color: list[int] = field(default_factory=lambda: [0, 0, 0])
    reverse: bool = False
    minimum_one_led_when_active: bool = True
    smooth_partial_led: bool = True
    restore_on_startup: bool = True
    monitor_dolphin_copies: bool = True

    # Si true, le lancement normal se comporte comme --monitor-only.
    monitor_only: bool = False

    @classmethod
    def load(cls, path: Path) -> "Config":
        if not path.exists():
            raise SteamRGBError(
                f"Fichier de configuration introuvable : {path}\n"
                "Lance d'abord le script install.sh ou copie config.example.json."
            )
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise SteamRGBError(f"Configuration invalide ({path}) : {exc}") from exc

        known = {name for name in cls.__dataclass_fields__}
        unknown = sorted(set(raw) - known)
        if unknown:
            LOG.warning("Clés de configuration inconnues ignorées : %s", ", ".join(unknown))

        cfg = cls(**{k: v for k, v in raw.items() if k in known})
        cfg.validate()
        return cfg

    def validate(self) -> None:
        if not self.steam_cef_targets_url.startswith(("http://", "https://")):
            raise SteamRGBError("steam_cef_targets_url doit être une URL HTTP.")
        if not self.openlinkhub_url.startswith(("http://", "https://")):
            raise SteamRGBError("openlinkhub_url doit être une URL HTTP.")
        if not (1 <= int(self.openrgb_port) <= 65535):
            raise SteamRGBError("openrgb_port doit être compris entre 1 et 65535.")
        if self.poll_interval_seconds < 0.1:
            raise SteamRGBError("poll_interval_seconds doit être >= 0.1.")
        if self.idle_restore_delay_seconds < 0:
            raise SteamRGBError("idle_restore_delay_seconds doit être >= 0.")
        for name, color in (
            ("filled_color", self.filled_color),
            ("copy_filled_color", self.copy_filled_color),
            ("empty_color", self.empty_color),
        ):
            if len(color) != 3 or any(not isinstance(x, int) or not 0 <= x <= 255 for x in color):
                raise SteamRGBError(f"{name} doit contenir trois entiers entre 0 et 255.")
        if any(not isinstance(z, int) or z < 0 for z in self.zones):
            raise SteamRGBError("zones doit contenir des numéros de zone entiers positifs.")


@dataclass(slots=True)
class DownloadState:
    active: bool = False
    paused: bool = False
    progress: float = 0.0
    downloaded_bytes: int = 0
    total_bytes: int = 0
    app_id: int = 0
    state_name: str = "None"
    network_bytes_per_second: int = 0
    seconds_remaining: int = 0
    source: str = "none"
    sequence: int = 0

    @property
    def percent(self) -> float:
        return max(0.0, min(100.0, self.progress * 100.0))


@dataclass(slots=True)
class CopyState:
    active: bool = False
    progress: float = 0.0
    processed_bytes: int = 0
    total_bytes: int = 0
    job_count: int = 0

    @property
    def percent(self) -> float:
        return max(0.0, min(100.0, self.progress * 100.0))


@dataclass(slots=True)
class _CopyJob:
    path: str
    title: str = ""
    progress: float = 0.0
    processed_bytes: int = 0
    total_bytes: int = 0


class DolphinCopyMonitor:
    """Suit les tâches de copie Dolphin publiées vers KDE JobViewServer.

    On utilise l'outil système ``dbus-monitor`` déjà présent dans SteamOS afin
    de ne pas ajouter de dépendance Python D-Bus. Les tâches sont identifiées
    par ``org.kde.JobViewV3`` et le titre localisé ``Copie``/``Copy``.
    """

    _MESSAGE_START = re.compile(r"^(?:method call|method return|signal|error) ")
    _PATH = re.compile(r"\bpath=([^;]+);")
    _DICT_ENTRY = re.compile(
        r'dict entry\(\s*string "([^"]+)"\s*variant\s+([A-Za-z0-9_]+)\s+(.+?)\s*\)',
        re.DOTALL,
    )
    _COPY_TITLES = {
        "copie",
        "copy",
        "kopieren",
        "copiar",
        "copia",
    }

    def __init__(self, reconnect_delay_seconds: float = 2.0) -> None:
        self.reconnect_delay_seconds = max(0.2, reconnect_delay_seconds)
        self._jobs: dict[str, _CopyJob] = {}
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._process: Optional[subprocess.Popen[str]] = None

    @staticmethod
    def available() -> bool:
        try:
            result = subprocess.run(
                ["sh", "-c", "command -v dbus-monitor"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
                timeout=2.0,
            )
            return result.returncode == 0
        except (OSError, subprocess.SubprocessError):
            return False

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        if not self.available():
            raise SteamRGBError("dbus-monitor est introuvable : suivi des copies Dolphin impossible.")
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            name="DolphinCopyMonitor",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        process = self._process
        if process is not None and process.poll() is None:
            try:
                process.terminate()
            except OSError:
                pass
        thread = self._thread
        if thread is not None:
            thread.join(timeout=3.0)
        self._thread = None
        self._process = None
        with self._lock:
            self._jobs.clear()

    def snapshot(self) -> CopyState:
        with self._lock:
            jobs = list(self._jobs.values())

        if not jobs:
            return CopyState()

        known = [job for job in jobs if job.total_bytes > 0]
        unknown = [job for job in jobs if job.total_bytes <= 0]

        if known and not unknown:
            total = sum(job.total_bytes for job in known)
            processed = sum(min(job.processed_bytes, job.total_bytes) for job in known)
            progress = processed / total if total > 0 else 0.0
            return CopyState(True, progress, processed, total, len(jobs))

        # Repli pour une tâche qui n'annonce pas sa taille : moyenne des
        # pourcentages publiés. Les tâches connues sont également représentées.
        progress = sum(job.progress for job in jobs) / len(jobs)
        processed = sum(job.processed_bytes for job in jobs)
        total = sum(job.total_bytes for job in known)
        return CopyState(True, progress, processed, total, len(jobs))

    def _run(self) -> None:
        while not self._stop_event.is_set():
            try:
                self._process = subprocess.Popen(
                    [
                        "dbus-monitor",
                        "--session",
                        "destination='org.kde.JobViewServer'",
                    ],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                )
                LOG.info("Surveillance des copies Dolphin/KIO active.")
                self._consume(self._process)
            except OSError as exc:
                LOG.warning("Surveillance Dolphin indisponible : %s", exc)
            finally:
                process = self._process
                if process is not None and process.poll() is None:
                    try:
                        process.terminate()
                    except OSError:
                        pass
                if process is not None:
                    try:
                        process.wait(timeout=1.0)
                    except subprocess.TimeoutExpired:
                        try:
                            process.kill()
                            process.wait(timeout=1.0)
                        except (OSError, subprocess.SubprocessError):
                            pass
                    if process.stdout is not None:
                        process.stdout.close()
                self._process = None
                with self._lock:
                    self._jobs.clear()

            if not self._stop_event.is_set():
                LOG.warning(
                    "Surveillance Dolphin interrompue ; nouvelle tentative dans %.1f s.",
                    self.reconnect_delay_seconds,
                )
                self._stop_event.wait(self.reconnect_delay_seconds)

    def _consume(self, process: subprocess.Popen[str]) -> None:
        if process.stdout is None:
            return

        block: list[str] = []
        for raw_line in process.stdout:
            if self._stop_event.is_set():
                break
            line = raw_line.rstrip("\n")
            if self._MESSAGE_START.match(line):
                if block:
                    self._handle_block(block)
                block = [line]
            elif block:
                block.append(line)
        if block:
            self._handle_block(block)

    @classmethod
    def _decode_value(cls, value_type: str, raw: str) -> Any:
        raw = raw.strip()
        try:
            if value_type == "string":
                return json.loads(raw)
            if value_type in {"uint32", "uint64", "int32", "int64", "byte"}:
                return int(raw.split()[0])
            if value_type == "double":
                return float(raw.split()[0])
            if value_type == "boolean":
                return raw.split()[0].lower() == "true"
        except (ValueError, json.JSONDecodeError):
            pass
        return raw

    @classmethod
    def _parse_properties(cls, text: str) -> dict[str, Any]:
        properties: dict[str, Any] = {}
        for match in cls._DICT_ENTRY.finditer(text):
            key, value_type, raw = match.groups()
            properties[key] = cls._decode_value(value_type, raw)
        return properties

    @classmethod
    def _is_copy_title(cls, title: str) -> bool:
        return title.strip().casefold() in cls._COPY_TITLES

    def _handle_block(self, lines: list[str]) -> None:
        if not lines:
            return
        header = lines[0]
        if "interface=org.kde.JobViewV3;" not in header:
            return

        path_match = self._PATH.search(header)
        if not path_match:
            return
        path = path_match.group(1)

        if "member=update" in header:
            properties = self._parse_properties("\n".join(lines[1:]))
            with self._lock:
                job = self._jobs.get(path)
                title = str(properties.get("title", job.title if job else ""))

                if job is None and not self._is_copy_title(title):
                    return
                if job is None:
                    job = _CopyJob(path=path, title=title)
                    self._jobs[path] = job
                    LOG.info("Copie Dolphin détectée : %s", path.rsplit("/", 1)[-1])

                if title:
                    job.title = title
                if "percent" in properties:
                    job.progress = max(0.0, min(1.0, float(properties["percent"]) / 100.0))
                if "processedBytes" in properties:
                    job.processed_bytes = max(0, int(properties["processedBytes"]))
                if "totalBytes" in properties:
                    job.total_bytes = max(0, int(properties["totalBytes"]))

                # Le calcul par octets est plus précis que le pourcentage entier.
                if job.total_bytes > 0:
                    job.progress = max(
                        0.0,
                        min(1.0, job.processed_bytes / job.total_bytes),
                    )

        elif "member=terminate" in header:
            status_match = re.search(r"\buint32\s+(\d+)", "\n".join(lines[1:]))
            status = int(status_match.group(1)) if status_match else -1
            with self._lock:
                job = self._jobs.pop(path, None)
            if job is not None:
                if status == 0:
                    LOG.info("Copie Dolphin terminée.")
                else:
                    LOG.info("Copie Dolphin arrêtée (code %d).", status)


class CdpSession:
    """Petite connexion synchrone au Chrome DevTools Protocol."""

    def __init__(self, websocket_url: str, timeout: float = 5.0) -> None:
        self.websocket_url = websocket_url
        self.timeout = timeout
        self._ws: Optional[websocket.WebSocket] = None
        self._next_id = 1

    def connect(self) -> None:
        self.close()
        # Steam CEF peut refuser l'en-tête Origin par défaut.
        self._ws = websocket.create_connection(
            self.websocket_url,
            timeout=self.timeout,
            suppress_origin=True,
            enable_multithread=True,
        )
        self.call("Runtime.enable")

    def close(self) -> None:
        if self._ws is not None:
            try:
                self._ws.close()
            except Exception:
                pass
            self._ws = None

    def call(self, method: str, params: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        if self._ws is None:
            raise SteamRGBError("Connexion CEF non ouverte.")

        msg_id = self._next_id
        self._next_id += 1
        payload = {"id": msg_id, "method": method}
        if params is not None:
            payload["params"] = params

        try:
            self._ws.send(json.dumps(payload))
            deadline = time.monotonic() + self.timeout
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError(f"Délai dépassé pour {method}")
                self._ws.settimeout(remaining)
                raw = self._ws.recv()
                response = json.loads(raw)
                # Les notifications CDP n'ont pas d'id : on les ignore.
                if response.get("id") != msg_id:
                    continue
                if "error" in response:
                    raise SteamRGBError(f"Erreur CDP {method} : {response['error']}")
                return response
        except (OSError, TimeoutError, websocket.WebSocketException, json.JSONDecodeError) as exc:
            self.close()
            raise SteamRGBError(f"Connexion CEF perdue : {exc}") from exc

    def evaluate(self, expression: str) -> Any:
        response = self.call(
            "Runtime.evaluate",
            {
                "expression": expression,
                "returnByValue": True,
                "awaitPromise": True,
                "userGesture": False,
            },
        )
        result = response.get("result", {}).get("result", {})
        if result.get("subtype") == "error":
            raise SteamRGBError(f"Erreur JavaScript CEF : {result.get('description', result)}")
        if "exceptionDetails" in response.get("result", {}):
            details = response["result"]["exceptionDetails"]
            raise SteamRGBError(f"Exception JavaScript CEF : {details}")
        return result.get("value")


class SteamDownloadReader:
    """
    Découvre dynamiquement SharedJSContext puis installe deux abonnements :
    - RegisterForDownloadItems
    - RegisterForDownloadOverview

    Les données sont normalisées dans window.__steamDownloadRGB_v5.
    """

    JS_KEY = "__steamDownloadRGB_v5"

    INSTALL_JS = r"""
(() => {
    const KEY = "__steamDownloadRGB_v5";

    const num = (v) => {
        if (v === null || v === undefined) return 0;

        if (typeof v === "number") {
            return Number.isFinite(v) ? v : 0;
        }

        if (typeof v === "bigint") {
            const n = Number(v);
            return Number.isFinite(n) ? n : 0;
        }

        if (typeof v === "string") {
            const n = Number(v);
            return Number.isFinite(n) ? n : 0;
        }

        if (typeof v === "object") {
            try {
                if (typeof v.toNumber === "function") {
                    const n = Number(v.toNumber());
                    if (Number.isFinite(n)) return n;
                }

                if (typeof v.toString === "function") {
                    const text = v.toString();
                    if (text && text !== "[object Object]") {
                        const n = Number(text);
                        if (Number.isFinite(n)) return n;
                    }
                }

                const low = Number(v.low ?? v.lo ?? v.low_);
                const high = Number(v.high ?? v.hi ?? v.high_);

                if (Number.isFinite(low) && Number.isFinite(high)) {
                    return (high >>> 0) * 4294967296 + (low >>> 0);
                }
            } catch (_) {
                return 0;
            }
        }

        return 0;
    };

    const bool = (v) => Boolean(v);

    const simplifyProgressArray = (progress) => {
        if (!Array.isArray(progress)) return [];

        return progress.map((entry) => ({
            bytes_in_progress: num(
                entry?.bytes_in_progress ?? entry?.bytesInProgress
            ),
            bytes_total: num(entry?.bytes_total ?? entry?.bytesTotal),
            estimated_time_remaining_sec: num(
                entry?.estimated_time_remaining_sec
                ?? entry?.estimatedTimeRemainingSec
            )
        }));
    };

    const largestProgressEntry = (progress) => {
        const entries = simplifyProgressArray(progress);
        let selected = null;

        for (const entry of entries) {
            if (entry.bytes_total <= 0) continue;

            if (
                selected === null
                || entry.bytes_total > selected.bytes_total
            ) {
                selected = entry;
            }
        }

        return selected ?? {
            bytes_in_progress: 0,
            bytes_total: 0,
            estimated_time_remaining_sec: 0
        };
    };

    const chooseUpdateInfo = (item) => {
        const infos = Array.isArray(item?.update_type_info)
            ? item.update_type_info
            : Array.isArray(item?.updateTypeInfo)
                ? item.updateTypeInfo
                : [];

        return (
            infos.find(
                (info) => bool(info?.has_update ?? info?.hasUpdate)
                    && !bool(
                        info?.completed_update ?? info?.completedUpdate
                    )
            )
            ?? infos.find(
                (info) => bool(info?.has_update ?? info?.hasUpdate)
            )
            ?? infos.find(
                (info) => num(
                    info?.overall_percent_complete
                    ?? info?.overallPercentComplete
                ) > 0
            )
            ?? null
        );
    };

    const simplifyItem = (item) => {
        const updateInfo = chooseUpdateInfo(item);
        const progressEntry = largestProgressEntry(updateInfo?.progress);

        return {
            active: bool(item?.active),
            appid: num(item?.appid ?? item?.appId),
            completed: bool(item?.completed),
            downloaded_bytes: progressEntry.bytes_in_progress,
            paused: bool(item?.paused),
            progress_percent: num(
                updateInfo?.overall_percent_complete
                ?? updateInfo?.overallPercentComplete
            ),
            queue_index: num(item?.queue_index ?? item?.queueIndex),
            seconds_remaining: num(
                updateInfo?.overall_estimated_time_remaining_sec
                ?? updateInfo?.overallEstimatedTimeRemainingSec
                ?? progressEntry.estimated_time_remaining_sec
            ),
            total_bytes: progressEntry.bytes_total,
            update_error: String(
                item?.update_error ?? item?.updateError ?? ""
            )
        };
    };

    const flattenItems = (payload) => {
        if (!Array.isArray(payload)) return [];

        const result = [];

        for (const group of payload) {
            const itemData = Array.isArray(group?.item_data)
                ? group.item_data
                : Array.isArray(group?.itemData)
                    ? group.itemData
                    : [group];

            for (const item of itemData) {
                if (item && typeof item === "object") {
                    result.push(simplifyItem(item));
                }
            }
        }

        return result;
    };

    const simplifyOverview = (overview) => {
        const progressEntry = largestProgressEntry(overview?.progress);

        return {
            paused: bool(overview?.paused),
            progress_percent: num(
                overview?.overall_percent_complete
                ?? overview?.overallPercentComplete
            ),
            update_appid: num(
                overview?.update_appid ?? overview?.updateAppId
            ),
            update_bytes_downloaded: progressEntry.bytes_in_progress,
            update_bytes_to_download: progressEntry.bytes_total,
            update_network_bytes_per_second: num(
                overview?.update_network_bytes_per_second
                ?? overview?.updateNetworkBytesPerSecond
            ),
            update_seconds_remaining: num(
                overview?.overall_estimated_time_remaining_sec
                ?? overview?.overallEstimatedTimeRemainingSec
                ?? progressEntry.estimated_time_remaining_sec
            ),
            update_state: String(
                overview?.update_state ?? overview?.updateState ?? "None"
            )
        };
    };

    // Si le contexte a été conservé, ne pas enregistrer deux fois les callbacks.
    if (window[KEY]?.ready) {
        return { ready: true, reused: true, error: null };
    }

    const state = window[KEY] = {
        ready: false,
        error: null,
        isDownloading: false,
        items: [],
        overview: null,
        sequence: 0,
        registeredAt: Date.now(),
        subscriptions: []
    };

    try {
        const downloads = window.SteamClient?.Downloads;

        if (!downloads) {
            throw new Error(
                "SteamClient.Downloads est absent de SharedJSContext"
            );
        }

        if (typeof downloads.RegisterForDownloadItems !== "function") {
            throw new Error("RegisterForDownloadItems est indisponible");
        }

        if (typeof downloads.RegisterForDownloadOverview !== "function") {
            throw new Error("RegisterForDownloadOverview est indisponible");
        }

        const subItems = downloads.RegisterForDownloadItems(
            (isDownloading, payload) => {
                state.isDownloading = Boolean(isDownloading);
                state.items = flattenItems(payload);
                state.sequence++;
            }
        );

        const subOverview = downloads.RegisterForDownloadOverview(
            (overview) => {
                state.overview = simplifyOverview(overview);
                state.sequence++;
            }
        );

        // Garder les objets d'abonnement en vie dans le contexte JS.
        state.subscriptions.push(subItems, subOverview);
        state.ready = true;

        return { ready: true, reused: false, error: null };
    } catch (error) {
        state.error = String(error?.stack || error);

        return {
            ready: false,
            reused: false,
            error: state.error
        };
    }
})()
"""

    READ_JS = r"""
(() => {
    const state = window.__steamDownloadRGB_v5;

    if (!state) {
        return {
            ready: false,
            error: "Abonnements absents"
        };
    }

    return {
        ready: Boolean(state.ready),
        error: state.error,
        isDownloading: Boolean(state.isDownloading),
        items: Array.isArray(state.items) ? state.items : [],
        overview: state.overview,
        sequence: Number(state.sequence || 0),
        ageMs: Date.now() - Number(state.registeredAt || Date.now())
    };
})()
"""

    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg
        self.session: Optional[CdpSession] = None
        self.current_target_id: Optional[str] = None

    def close(self) -> None:
        if self.session:
            self.session.close()
        self.session = None
        self.current_target_id = None

    def _discover_target(self) -> dict[str, Any]:
        try:
            response = requests.get(
                self.cfg.steam_cef_targets_url,
                timeout=self.cfg.request_timeout_seconds,
            )
            response.raise_for_status()
            targets = response.json()
        except (requests.RequestException, ValueError) as exc:
            raise SteamRGBError(
                "Impossible de joindre Steam CEF sur "
                f"{self.cfg.steam_cef_targets_url} : {exc}"
            ) from exc

        if not isinstance(targets, list):
            raise SteamRGBError("Réponse CEF inattendue : une liste était attendue.")

        # SharedJSContext est la cible privilégiée.
        for target in targets:
            if target.get("title") == "SharedJSContext" and target.get("webSocketDebuggerUrl"):
                return target

        # Secours si Valve modifie légèrement le titre.
        for target in targets:
            title = str(target.get("title", "")).lower()
            url = str(target.get("url", "")).lower()
            if (
                ("sharedjs" in title or "steamloopback.host" in url)
                and target.get("webSocketDebuggerUrl")
            ):
                return target

        titles = ", ".join(str(t.get("title", "?")) for t in targets[-8:])
        raise SteamRGBError(
            "SharedJSContext introuvable dans Steam CEF. "
            f"Cibles vues : {titles or 'aucune'}"
        )

    def connect(self) -> None:
        target = self._discover_target()
        ws_url = str(target["webSocketDebuggerUrl"])
        session = CdpSession(ws_url, timeout=max(5.0, self.cfg.request_timeout_seconds))
        session.connect()
        install_result = session.evaluate(self.INSTALL_JS)

        if not isinstance(install_result, dict) or not install_result.get("ready"):
            error = install_result.get("error") if isinstance(install_result, dict) else install_result
            session.close()
            raise SteamRGBError(f"Impossible d'installer les abonnements Steam : {error}")

        self.close()
        self.session = session
        self.current_target_id = str(target.get("id", ""))
        LOG.info(
            "Steam CEF connecté à SharedJSContext%s.",
            " (abonnements déjà présents)" if install_result.get("reused") else "",
        )

    def read(self) -> DownloadState:
        if self.session is None:
            self.connect()

        assert self.session is not None
        raw = self.session.evaluate(self.READ_JS)
        if not isinstance(raw, dict) or not raw.get("ready"):
            raise SteamRGBError(f"État Steam indisponible : {raw}")

        return self._normalise(raw)

    @staticmethod
    def _normalise(raw: dict[str, Any]) -> DownloadState:
        items = (
            raw.get("items")
            if isinstance(raw.get("items"), list)
            else []
        )

        overview = (
            raw.get("overview")
            if isinstance(raw.get("overview"), dict)
            else {}
        )

        overview_appid = int(
            float(overview.get("update_appid") or 0)
        )

        active_items = [
            item
            for item in items
            if (
                isinstance(item, dict)
                and bool(item.get("active"))
                and not bool(item.get("paused"))
            )
        ]

        if active_items:
            selected = next(
                (
                    item
                    for item in active_items
                    if int(float(item.get("appid") or 0))
                    == overview_appid
                    and overview_appid > 0
                ),
                active_items[0],
            )

            selected_appid = int(float(selected.get("appid") or 0))
            state_name = str(
                overview.get("update_state") or "Downloading"
            )

            # Sur SteamOS actuel, update_type_info peut rester figé à 0/1 %
            # alors que l'overview évolue réellement à chaque seconde. Quand
            # l'overview concerne le même AppID et signale une phase active,
            # il doit donc être prioritaire pour la barre et les LED.
            overview_matches_active_item = (
                bool(raw.get("isDownloading"))
                and not bool(overview.get("paused"))
                and overview_appid == selected_appid
                and overview_appid > 0
                and state_name
                in {
                    "Starting",
                    "Updating",
                    "Downloading",
                    "Stopping",
                }
            )

            if overview_matches_active_item:
                downloaded = max(
                    0,
                    int(
                        float(
                            overview.get("update_bytes_downloaded")
                            or 0
                        )
                    ),
                )
                total = max(
                    0,
                    int(
                        float(
                            overview.get("update_bytes_to_download")
                            or 0
                        )
                    ),
                )
                percent = max(
                    0.0,
                    min(
                        100.0,
                        float(overview.get("progress_percent") or 0),
                    ),
                )
                seconds_remaining = int(
                    float(
                        overview.get("update_seconds_remaining")
                        or selected.get("seconds_remaining")
                        or 0
                    )
                )
                source = "overview"
            else:
                downloaded = max(
                    0,
                    int(float(selected.get("downloaded_bytes") or 0)),
                )
                total = max(
                    0,
                    int(float(selected.get("total_bytes") or 0)),
                )
                percent = max(
                    0.0,
                    min(
                        100.0,
                        float(selected.get("progress_percent") or 0),
                    ),
                )
                seconds_remaining = int(
                    float(
                        selected.get("seconds_remaining")
                        or overview.get("update_seconds_remaining")
                        or 0
                    )
                )
                source = "items"

            if percent <= 0 and total > 0:
                percent = max(
                    0.0,
                    min(100.0, downloaded / total * 100.0),
                )

            return DownloadState(
                active=True,
                paused=False,
                progress=percent / 100.0,
                downloaded_bytes=downloaded,
                total_bytes=total,
                app_id=selected_appid,
                state_name=state_name,
                network_bytes_per_second=int(
                    float(
                        overview.get(
                            "update_network_bytes_per_second"
                        )
                        or 0
                    )
                ),
                seconds_remaining=max(0, seconds_remaining),
                source=source,
                sequence=int(float(raw.get("sequence") or 0)),
            )

        state_name = str(
            overview.get("update_state") or "None"
        )

        paused = bool(overview.get("paused"))

        overview_active = (
            not paused
            and bool(raw.get("isDownloading"))
            and state_name
            in {
                "Starting",
                "Updating",
                "Downloading",
                "Stopping",
            }
            and overview_appid > 0
        )

        downloaded = max(
            0,
            int(
                float(
                    overview.get("update_bytes_downloaded")
                    or 0
                )
            ),
        )

        total = max(
            0,
            int(
                float(
                    overview.get("update_bytes_to_download")
                    or 0
                )
            ),
        )

        percent = max(
            0.0,
            min(
                100.0,
                float(
                    overview.get("progress_percent")
                    or 0
                ),
            ),
        )

        if percent <= 0 and total > 0:
            percent = max(
                0.0,
                min(100.0, downloaded / total * 100.0),
            )

        return DownloadState(
            active=overview_active,
            paused=paused,
            progress=percent / 100.0,
            downloaded_bytes=downloaded,
            total_bytes=total,
            app_id=overview_appid,
            state_name=state_name,
            network_bytes_per_second=int(
                float(
                    overview.get(
                        "update_network_bytes_per_second"
                    )
                    or 0
                )
            ),
            seconds_remaining=max(
                0,
                int(
                    float(
                        overview.get("update_seconds_remaining")
                        or 0
                    )
                ),
            ),
            source="overview" if overview else "none",
            sequence=int(float(raw.get("sequence") or 0)),
        )


class OpenLinkHubController:
    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg
        self.base_url = cfg.openlinkhub_url.rstrip("/")
        self.session = requests.Session()
        self.serial: str = cfg.commander_serial
        self.saved_profiles: dict[int, str] = {}
        self.integration_enabled = False
        self.current_openrgb_integration = False

    def close(self) -> None:
        self.session.close()

    def _get(self, path: str) -> dict[str, Any]:
        try:
            response = self.session.get(
                f"{self.base_url}{path}",
                timeout=self.cfg.request_timeout_seconds,
            )
            response.raise_for_status()
            data = response.json()
        except (requests.RequestException, ValueError) as exc:
            raise SteamRGBError(f"Erreur OpenLinkHub GET {path} : {exc}") from exc
        if not isinstance(data, dict):
            raise SteamRGBError(f"Réponse OpenLinkHub invalide pour {path}.")
        return data

    def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            response = self.session.post(
                f"{self.base_url}{path}",
                json=payload,
                timeout=self.cfg.request_timeout_seconds,
            )
            response.raise_for_status()
            data = response.json()
        except (requests.RequestException, ValueError) as exc:
            raise SteamRGBError(f"Erreur OpenLinkHub POST {path} : {exc}") from exc
        if not isinstance(data, dict):
            raise SteamRGBError(f"Réponse OpenLinkHub invalide pour {path}.")
        return data

    def inspect_device(self) -> dict[str, Any]:
        data = self._get("/api/devices/")
        devices = data.get("devices")
        if not isinstance(devices, dict):
            raise SteamRGBError("OpenLinkHub n'a renvoyé aucune table de périphériques.")

        if self.serial and self.serial in devices:
            device_entry = devices[self.serial]
        else:
            needle = self.cfg.commander_name_contains.lower()
            matches = [
                (serial, entry)
                for serial, entry in devices.items()
                if needle in str(entry.get("Product", "")).lower()
            ]
            if len(matches) != 1:
                raise SteamRGBError(
                    f"Impossible d'identifier automatiquement {self.cfg.commander_name_contains!r}. "
                    f"Correspondances : {len(matches)}"
                )
            self.serial, device_entry = matches[0]

        get_device = device_entry.get("GetDevice")
        if not isinstance(get_device, dict):
            raise SteamRGBError("Données détaillées du Commander absentes.")

        profile = get_device.get("DeviceProfile")
        if not isinstance(profile, dict):
            raise SteamRGBError("DeviceProfile OpenLinkHub absent.")

        rgb_profiles = profile.get("RGBProfiles")
        if not isinstance(rgb_profiles, dict):
            raise SteamRGBError("RGBProfiles OpenLinkHub absent.")

        self.current_openrgb_integration = bool(profile.get("OpenRGBIntegration"))
        self.saved_profiles = {
            int(channel): str(profile_name)
            for channel, profile_name in rgb_profiles.items()
            if str(channel).lstrip("-").isdigit()
        }
        return get_device

    @staticmethod
    def _response_success(data: dict[str, Any]) -> bool:
        # Les actions POST OpenLinkHub renvoient status=1 en cas de succès.
        # status=0 correspond à un refus ou à une erreur applicative, même si
        # le code HTTP reste 200.
        code = int(data.get("code", 200))
        try:
            status = int(data.get("status", 0))
        except (TypeError, ValueError):
            status = 0
        return 200 <= code < 300 and status == 1

    def set_openrgb_integration(self, enabled: bool) -> None:
        if not self.serial:
            self.inspect_device()

        payload = {"deviceId": self.serial, "mode": 1 if enabled else 0}
        data = self._post("/api/color/setOpenRgbIntegration", payload)
        if not self._response_success(data):
            raise SteamRGBError(
                "OpenLinkHub a refusé le changement d'intégration OpenRGB : "
                f"{json.dumps(data, ensure_ascii=False)}"
            )
        self.integration_enabled = enabled
        self.current_openrgb_integration = enabled
        LOG.info("Intégration OpenRGB OpenLinkHub : %s.", "activée" if enabled else "désactivée")

    def restore_profiles(self) -> None:
        errors: list[str] = []

        # Désactiver d'abord l'intégration : OpenLinkHub reprend alors son moteur RGB.
        if self.integration_enabled:
            try:
                self.set_openrgb_integration(False)
            except Exception as exc:
                errors.append(f"désactivation OpenRGB : {exc}")
                self.integration_enabled = False

        # Réappliquer explicitement les profils mémorisés, canal par canal.
        for channel, profile in sorted(self.saved_profiles.items()):
            try:
                data = self._post(
                    "/api/color",
                    {"deviceId": self.serial, "channelId": channel, "profile": profile},
                )
                if not self._response_success(data):
                    errors.append(f"canal {channel} ({profile}) : {data}")
            except Exception as exc:
                errors.append(f"canal {channel} ({profile}) : {exc}")

        if errors:
            raise SteamRGBError("Restauration RGB incomplète : " + " ; ".join(errors))
        if self.saved_profiles:
            LOG.info(
                "Profils OpenLinkHub restaurés : %s.",
                ", ".join(f"canal {c}={p}" for c, p in sorted(self.saved_profiles.items())),
            )


class OpenRgbProgressBar:
    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg
        self.client: Optional[OpenRGBClient] = None
        self.device: Any = None
        self.selected_zones: list[Any] = []
        self.last_signature: Optional[tuple[int, ...]] = None

    @staticmethod
    def tcp_available(host: str, port: int, timeout: float = 1.5) -> bool:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except OSError:
            return False

    def connect(self, *, set_custom_mode: bool = True) -> None:
        self.disconnect()
        if not self.tcp_available(self.cfg.openrgb_host, self.cfg.openrgb_port):
            raise SteamRGBError(
                f"Serveur OpenRGB inaccessible sur "
                f"{self.cfg.openrgb_host}:{self.cfg.openrgb_port}. "
                "Active enableOpenRGBTargetServer dans OpenLinkHub."
            )

        try:
            self.client = OpenRGBClient(
                address=self.cfg.openrgb_host,
                port=int(self.cfg.openrgb_port),
                name=APP_NAME,
            )
        except Exception as exc:
            raise SteamRGBError(f"Connexion au serveur OpenRGB impossible : {exc}") from exc

        needle = self.cfg.openrgb_device_name_contains.lower()
        matches = [
            device
            for device in self.client.devices
            if needle in str(getattr(device, "name", "")).lower()
        ]
        if not matches and len(self.client.devices) == 1:
            matches = [self.client.devices[0]]
        if not matches:
            names = ", ".join(str(getattr(d, "name", "?")) for d in self.client.devices)
            self.disconnect()
            raise SteamRGBError(
                f"Périphérique OpenRGB {self.cfg.openrgb_device_name_contains!r} introuvable. "
                f"Périphériques vus : {names or 'aucun'}"
            )

        self.device = matches[0]
        if set_custom_mode:
            try:
                self.device.set_custom_mode()
            except Exception as exc:
                # Certains serveurs exposent déjà un unique mode direct.
                LOG.warning("Le passage explicite en mode direct a échoué, poursuite : %s", exc)

        zones = list(getattr(self.device, "zones", []))
        wanted = self.cfg.zones or list(range(len(zones)))
        selected: list[Any] = []
        missing: list[int] = []
        for index in wanted:
            if 0 <= index < len(zones):
                zone = zones[index]
                if len(getattr(zone, "leds", [])) > 0:
                    selected.append(zone)
                else:
                    LOG.warning("Zone OpenRGB %d ignorée : aucune LED déclarée.", index)
            else:
                missing.append(index)

        if missing:
            LOG.warning("Zones OpenRGB absentes ignorées : %s", missing)
        if not selected:
            counts = [len(getattr(z, "leds", [])) for z in zones]
            self.disconnect()
            raise SteamRGBError(
                "Aucune zone OpenRGB utilisable. "
                f"Nombre de LED par zone annoncé : {counts}. "
                "Vérifie le nombre de LED des canaux ARGB dans OpenLinkHub."
            )

        selected_led_count = sum(len(getattr(zone, "leds", [])) for zone in selected)
        device_led_count = len(getattr(self.device, "leds", []))
        if selected_led_count != device_led_count:
            self.disconnect()
            raise SteamRGBError(
                "L’écriture globale OpenRGB exige actuellement que toutes les zones LED "
                "du périphérique soient sélectionnées. "
                f"Zones sélectionnées : {selected_led_count} LED ; "
                f"périphérique : {device_led_count} LED."
            )

        self.selected_zones = selected
        self.last_signature = None
        LOG.info(
            "OpenRGB connecté à %s ; écriture globale sur %d LED ; zones : %s.",
            getattr(self.device, "name", "?"),
            device_led_count,
            ", ".join(
                f"{getattr(z, 'name', '?')} ({len(z.leds)} LED)"
                for z in self.selected_zones
            ),
        )

    def disconnect(self) -> None:
        if self.client is not None:
            try:
                self.client.disconnect()
            except Exception:
                pass
        self.client = None
        self.device = None
        self.selected_zones = []
        self.last_signature = None

    def render(
        self,
        progress: float,
        active: bool = True,
        force: bool = False,
        filled_color: Optional[list[int]] = None,
    ) -> None:
        if self.client is None:
            self.connect()

        progress = max(0.0, min(1.0, progress))
        filled_rgb = tuple(filled_color or self.cfg.filled_color)
        empty_rgb = tuple(self.cfg.empty_color)
        signatures: list[tuple[tuple[int, int, int], ...]] = []
        payloads: list[tuple[Any, list[RGBColor]]] = []

        def blend(fraction: float) -> tuple[int, int, int]:
            fraction = max(0.0, min(1.0, fraction))
            return tuple(
                int(round(empty + (filled - empty) * fraction))
                for empty, filled in zip(empty_rgb, filled_rgb)
            )

        for zone in self.selected_zones:
            count = len(zone.leds)
            scaled = progress * count
            full_leds = min(count, int(math.floor(scaled + 1e-9)))
            partial = 0.0 if full_leds >= count else scaled - full_leds

            # À très faible progression, conserver un minimum visible sans allumer
            # immédiatement une LED à pleine puissance. Cela rend aussi le canal
            # exposé comme une seule LED progressivement plus lumineux.
            if (
                self.cfg.smooth_partial_led
                and active
                and progress > 0
                and self.cfg.minimum_one_led_when_active
                and full_leds == 0
            ):
                partial = max(partial, 0.08)

            values: list[tuple[int, int, int]] = [filled_rgb] * full_leds

            if full_leds < count:
                if self.cfg.smooth_partial_led and partial > 0:
                    values.append(blend(partial))
                else:
                    values.append(empty_rgb)

            values.extend([empty_rgb] * (count - len(values)))

            if self.cfg.reverse:
                values.reverse()

            signatures.append(tuple(values))
            payloads.append(
                (zone, [RGBColor(red, green, blue) for red, green, blue in values])
            )

        signature = tuple(signatures)
        if not force and signature == self.last_signature:
            return

        # OpenLinkHub accepte correctement une écriture globale du COMMANDER DUO.
        # Les zones sont donc calculées séparément puis concaténées en une commande.
        device_colors: list[RGBColor] = []
        for _zone, colors in payloads:
            device_colors.extend(colors)

        try:
            self.device.set_colors(device_colors, fast=False)
        except Exception as exc:
            self.disconnect()
            raise SteamRGBError(f"Écriture OpenRGB globale impossible : {exc}") from exc

        self.last_signature = signature


def format_bytes(value: int) -> str:
    value_f = float(max(0, value))
    units = ["o", "Kio", "Mio", "Gio", "Tio"]
    for unit in units:
        if value_f < 1024.0 or unit == units[-1]:
            if unit == "o":
                return f"{int(value_f)} {unit}"
            return f"{value_f:.1f} {unit}"
        value_f /= 1024.0
    return f"{value_f:.1f} Tio"


def format_duration(seconds: int) -> str:
    seconds = max(0, int(seconds))
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return f"{hours} h {minutes:02d} min"
    if minutes:
        return f"{minutes} min {secs:02d} s"
    return f"{secs} s"



def format_download_status(prefix: str, state: DownloadState) -> str:
    parts = [f"{prefix} : {state.percent:.1f} %"]

    if state.total_bytes > 0:
        parts.append(
            f"{format_bytes(state.downloaded_bytes)} / "
            f"{format_bytes(state.total_bytes)}"
        )

    if state.network_bytes_per_second > 0:
        parts.append(
            f"{format_bytes(state.network_bytes_per_second)}/s"
        )

    if state.seconds_remaining > 0:
        parts.append(
            f"reste {format_duration(state.seconds_remaining)}"
        )

    if state.app_id > 0:
        parts.append(f"appid {state.app_id}")

    return " | ".join(parts)


def format_copy_status(prefix: str, state: CopyState) -> str:
    parts = [f"{prefix} : {state.percent:.1f} %"]
    if state.total_bytes > 0:
        parts.append(
            f"{format_bytes(state.processed_bytes)} / "
            f"{format_bytes(state.total_bytes)}"
        )
    if state.job_count > 1:
        parts.append(f"{state.job_count} copies")
    return " | ".join(parts)

def configure_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%H:%M:%S",
    )
    # Éviter les traces réseau trop bavardes en mode debug.
    logging.getLogger("urllib3").setLevel(logging.WARNING)


def diagnose(cfg: Config) -> int:
    print("=== Diagnostic Steam Download RGB ===")
    ok = True

    reader = SteamDownloadReader(cfg)
    try:
        reader.connect()
        state = reader.read()
        print(
            f"[OK] Steam CEF / SharedJSContext : état={state.state_name}, "
            f"actif={state.active}, source={state.source}"
        )
    except Exception as exc:
        ok = False
        print(f"[ERREUR] Steam CEF : {exc}")
    finally:
        reader.close()

    hub = OpenLinkHubController(cfg)
    try:
        device = hub.inspect_device()
        print(
            f"[OK] OpenLinkHub : {device.get('product', device.get('Product', '?'))} "
            f"({hub.serial})"
        )
        print(
            "[OK] Profils RGB actuels : "
            + ", ".join(f"canal {c}={p}" for c, p in sorted(hub.saved_profiles.items()))
        )
        print(
            "[INFO] Intégration OpenRGB actuellement enregistrée : "
            f"{hub.current_openrgb_integration}"
        )
    except Exception as exc:
        ok = False
        print(f"[ERREUR] OpenLinkHub : {exc}")
    finally:
        hub.close()

    # Le diagnostic reste entièrement passif. Un Commander dont
    # OpenRGBIntegration=false n'est pas forcément publié par le serveur,
    # donc on vérifie ici seulement que l'écoute TCP est disponible.
    if OpenRgbProgressBar.tcp_available(cfg.openrgb_host, cfg.openrgb_port):
        print(f"[OK] Serveur OpenRGB : {cfg.openrgb_host}:{cfg.openrgb_port}")
        print("[INFO] Les zones seront vérifiées par --led-test après activation temporaire de l'intégration.")
    else:
        ok = False
        print(
            f"[ERREUR] Serveur OpenRGB fermé sur "
            f"{cfg.openrgb_host}:{cfg.openrgb_port}"
        )

    if cfg.monitor_dolphin_copies:
        if DolphinCopyMonitor.available():
            print("[OK] Suivi Dolphin/KIO : dbus-monitor disponible")
        else:
            ok = False
            print("[ERREUR] Suivi Dolphin/KIO : dbus-monitor introuvable")

    print("Résultat :", "tout est prêt" if ok else "une correction est nécessaire")
    return 0 if ok else 1


def monitor_only(cfg: Config, stop_event: threading.Event) -> int:
    reader = SteamDownloadReader(cfg)
    copy_monitor = DolphinCopyMonitor(cfg.reconnect_delay_seconds)
    last_steam: Optional[tuple[Any, ...]] = None
    last_copy: Optional[tuple[Any, ...]] = None
    steam_retry_at = 0.0
    steam_error_visible = False
    LOG.info("Mode lecture seule : aucune LED ne sera modifiée.")

    if cfg.monitor_dolphin_copies:
        copy_monitor.start()

    try:
        while not stop_event.is_set():
            steam_state = DownloadState()
            now = time.monotonic()
            if now >= steam_retry_at:
                try:
                    steam_state = reader.read()
                    steam_error_visible = False
                except Exception as exc:
                    reader.close()
                    steam_retry_at = now + cfg.reconnect_delay_seconds
                    if not steam_error_visible:
                        LOG.warning("Steam indisponible : %s", exc)
                        steam_error_visible = True

            if steam_state.active:
                steam_marker = (
                    "active",
                    round(steam_state.percent, 1),
                    steam_state.state_name,
                    steam_state.app_id,
                )
            elif steam_state.paused:
                steam_marker = ("paused", steam_state.app_id)
            else:
                steam_marker = ("idle",)

            if steam_marker != last_steam:
                if steam_state.active:
                    LOG.info("%s", format_download_status("Steam", steam_state))
                elif steam_state.paused:
                    LOG.info("Steam : téléchargement en pause.")
                else:
                    LOG.info("Steam : aucun téléchargement actif.")
                last_steam = steam_marker

            copy_state = copy_monitor.snapshot() if cfg.monitor_dolphin_copies else CopyState()
            copy_marker = (
                "active",
                round(copy_state.percent, 1),
                copy_state.job_count,
            ) if copy_state.active else ("idle",)

            if copy_marker != last_copy:
                if copy_state.active:
                    LOG.info("%s", format_copy_status("Copie Dolphin", copy_state))
                else:
                    LOG.info("Dolphin : aucune copie active.")
                last_copy = copy_marker

            stop_event.wait(cfg.poll_interval_seconds)
    finally:
        reader.close()
        copy_monitor.stop()
    return 0

def led_test(cfg: Config) -> int:
    hub = OpenLinkHubController(cfg)
    rgb = OpenRgbProgressBar(cfg)
    restored = False
    try:
        device = hub.inspect_device()
        LOG.info(
            "Test sur %s (%s), profils sauvegardés : %s",
            device.get("product", "COMMANDER DUO"),
            hub.serial,
            hub.saved_profiles,
        )
        hub.set_openrgb_integration(True)
        time.sleep(0.4)
        rgb.connect()

        for percent in (0, 25, 50, 75, 100):
            LOG.info("Test LED : %d %%", percent)
            rgb.render(percent / 100.0, active=True, force=True)
            time.sleep(1.0)

        rgb.disconnect()
        hub.restore_profiles()
        restored = True
        LOG.info("Test terminé ; profils OpenLinkHub restaurés.")
        return 0
    finally:
        rgb.disconnect()
        if not restored:
            try:
                hub.restore_profiles()
            except Exception as exc:
                LOG.error("Échec de la restauration après test : %s", exc)
        hub.close()


def run_service(cfg: Config, stop_event: threading.Event) -> int:
    reader = SteamDownloadReader(cfg)
    copy_monitor = DolphinCopyMonitor(cfg.reconnect_delay_seconds)
    hub = OpenLinkHubController(cfg)
    rgb = OpenRgbProgressBar(cfg)

    controlling = False
    idle_since: Optional[float] = None
    last_progress_marker: Optional[tuple[Any, ...]] = None
    last_source: Optional[str] = None
    restored = False
    ever_controlled = False
    steam_retry_at = 0.0
    steam_error_visible = False
    copy_monitor_started = False

    try:
        hub.inspect_device()
        LOG.info(
            "Commander détecté : %s ; profils mémorisés : %s",
            hub.serial,
            ", ".join(f"{c}={p}" for c, p in sorted(hub.saved_profiles.items())),
        )

        if cfg.monitor_dolphin_copies and not stop_event.is_set():
            try:
                copy_monitor.start()
                copy_monitor_started = True
            except Exception as exc:
                LOG.warning("Suivi des copies Dolphin désactivé : %s", exc)

        # Récupération après coupure de courant, SIGKILL ou plantage : si une
        # ancienne exécution a laissé l'intégration OpenRGB active, rendre la
        # main à OpenLinkHub avant de commencer la surveillance.
        if cfg.restore_on_startup and hub.current_openrgb_integration:
            LOG.warning("Intégration OpenRGB déjà active au démarrage : restauration préventive.")
            hub.integration_enabled = True
            hub.restore_profiles()
            restored = True

        while not stop_event.is_set():
            try:
                now = time.monotonic()
                steam_state = DownloadState()

                # Le suivi Dolphin reste opérationnel même si Steam/CEF est
                # momentanément fermé ou indisponible.
                if now >= steam_retry_at:
                    try:
                        steam_state = reader.read()
                        steam_error_visible = False
                    except Exception as exc:
                        reader.close()
                        steam_retry_at = now + cfg.reconnect_delay_seconds
                        if not steam_error_visible:
                            LOG.warning(
                                "Steam indisponible ; le suivi Dolphin reste actif : %s",
                                exc,
                            )
                            steam_error_visible = True

                copy_state = (
                    copy_monitor.snapshot()
                    if copy_monitor_started
                    else CopyState()
                )

                source: Optional[str]
                progress = 0.0
                color = cfg.filled_color
                progress_marker: Optional[tuple[Any, ...]] = None

                if steam_state.active and not steam_state.paused:
                    source = "steam"
                    progress = steam_state.progress
                    color = cfg.filled_color
                    progress_marker = (
                        source,
                        round(steam_state.percent, 1),
                        steam_state.app_id,
                    )
                elif copy_state.active:
                    source = "dolphin"
                    progress = copy_state.progress
                    color = cfg.copy_filled_color
                    progress_marker = (
                        source,
                        round(copy_state.percent, 1),
                        copy_state.job_count,
                    )
                else:
                    source = None

                if source is not None:
                    idle_since = None

                    if not controlling:
                        if source == "steam":
                            LOG.info(
                                "Téléchargement Steam détecté : prise de contrôle temporaire des LED."
                            )
                        else:
                            LOG.info(
                                "Copie Dolphin détectée : prise de contrôle temporaire des LED."
                            )
                        hub.set_openrgb_integration(True)
                        time.sleep(0.35)
                        rgb.connect()
                        controlling = True
                        ever_controlled = True
                        restored = False
                    elif source != last_source:
                        if source == "steam":
                            LOG.info("Steam devient prioritaire sur la copie Dolphin.")
                        else:
                            LOG.info("Téléchargement Steam terminé ; reprise de la copie Dolphin.")

                    rgb.render(
                        progress,
                        active=True,
                        filled_color=color,
                    )

                    if progress_marker != last_progress_marker:
                        if source == "steam":
                            LOG.info(
                                "%s",
                                format_download_status("Progression Steam", steam_state),
                            )
                        else:
                            LOG.info(
                                "%s",
                                format_copy_status("Progression copie", copy_state),
                            )
                        last_progress_marker = progress_marker
                    last_source = source

                elif controlling:
                    if idle_since is None:
                        idle_since = time.monotonic()
                        LOG.info(
                            "Plus aucun téléchargement ni copie ; restauration dans %.1f s.",
                            cfg.idle_restore_delay_seconds,
                        )
                    elif time.monotonic() - idle_since >= cfg.idle_restore_delay_seconds:
                        rgb.disconnect()
                        hub.restore_profiles()
                        controlling = False
                        restored = True
                        idle_since = None
                        last_progress_marker = None
                        last_source = None
                        LOG.info("OpenLinkHub a repris le contrôle du profil température.")

                stop_event.wait(cfg.poll_interval_seconds)

            except Exception as exc:
                LOG.warning("Erreur temporaire : %s", exc)
                reader.close()

                # En cas de panne pendant le contrôle RGB, rendre immédiatement la main.
                if controlling or hub.integration_enabled:
                    rgb.disconnect()
                    try:
                        hub.restore_profiles()
                        restored = True
                    except Exception as restore_exc:
                        LOG.error("Restauration après erreur impossible : %s", restore_exc)
                    controlling = False
                    idle_since = None
                    last_progress_marker = None
                    last_source = None

                stop_event.wait(cfg.reconnect_delay_seconds)

        return 0
    finally:
        reader.close()
        copy_monitor.stop()
        rgb.disconnect()
        if controlling or hub.integration_enabled or (ever_controlled and not restored):
            try:
                hub.restore_profiles()
            except Exception as exc:
                LOG.error("Restauration finale OpenLinkHub impossible : %s", exc)
        hub.close()

def restore_only(cfg: Config) -> int:
    """Rend explicitement le contrôle RGB à OpenLinkHub."""
    hub = OpenLinkHubController(cfg)
    try:
        hub.inspect_device()
        # Ne désactiver l'intégration que si OpenLinkHub la déclare active.
        hub.integration_enabled = hub.current_openrgb_integration
        hub.restore_profiles()
        LOG.info("Restauration forcée terminée.")
        return 0
    finally:
        hub.close()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Affiche les téléchargements Steam et les copies Dolphin sur les LED OpenLinkHub/OpenRGB."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=DEFAULT_CONFIG_PATH,
        help=f"fichier JSON (défaut : {DEFAULT_CONFIG_PATH})",
    )
    parser.add_argument(
        "--diagnose",
        action="store_true",
        help="vérifie Steam, OpenLinkHub et OpenRGB sans modifier les LED",
    )
    parser.add_argument(
        "--monitor-only",
        action="store_true",
        help="affiche la progression dans le terminal sans modifier les LED",
    )
    parser.add_argument(
        "--led-test",
        action="store_true",
        help="affiche 0/25/50/75/100 %% puis restaure le profil température",
    )
    parser.add_argument(
        "--restore",
        action="store_true",
        help="désactive l'intégration OpenRGB et restaure immédiatement les profils OpenLinkHub",
    )
    parser.add_argument("-v", "--verbose", action="store_true", help="journaux détaillés")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    configure_logging(args.verbose)

    try:
        cfg = Config.load(args.config)
    except SteamRGBError as exc:
        LOG.error("%s", exc)
        return 2

    stop_event = threading.Event()

    def request_stop(signum: int, _frame: Any) -> None:
        LOG.info("Signal %s reçu : arrêt propre et restauration des LED.", signum)
        stop_event.set()

    signal.signal(signal.SIGINT, request_stop)
    signal.signal(signal.SIGTERM, request_stop)

    try:
        if args.restore:
            return restore_only(cfg)
        if args.diagnose:
            return diagnose(cfg)
        if args.led_test:
            return led_test(cfg)
        if args.monitor_only or cfg.monitor_only:
            return monitor_only(cfg, stop_event)
        return run_service(cfg, stop_event)
    except KeyboardInterrupt:
        stop_event.set()
        return 130
    except SteamRGBError as exc:
        LOG.error("%s", exc)
        return 1
    except Exception:
        LOG.exception("Erreur inattendue")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
