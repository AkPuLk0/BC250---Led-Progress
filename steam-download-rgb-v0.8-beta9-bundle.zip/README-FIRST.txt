Steam Download RGB v0.8 — paired update
========================================

Included:
- steam-download-rgb-v0.8-beta2.zip        Main user service
- steam-download-rgb-decky-v0.8-beta9.zip  Decky Loader settings plugin

Changes:
- progress is permanently left to right;
- the obsolete reverse key is removed from existing config.json files;
- the 2-second return delay after pause/end is unchanged;
- the bilingual language selector remains near the bottom of the Decky panel;
- the Decky systemctl/libcrypto fix is preserved.

Recommended order:
1. Update the main service from Desktop Mode.
2. Install the Decky beta 9 ZIP from Decky Developer settings.
3. Restart Decky Loader.
